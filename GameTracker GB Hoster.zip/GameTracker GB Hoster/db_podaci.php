<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'gbhoster_gt');
define('DB_PASS', '8DuSmJc4Jno&Gkq0{D');
define('DB_NAME', 'gbhoster_gametracker');
?>