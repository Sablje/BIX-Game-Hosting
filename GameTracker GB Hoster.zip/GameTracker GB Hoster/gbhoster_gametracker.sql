-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 31, 2018 at 01:00 PM
-- Server version: 5.6.42-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gbhoster_gametracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `acp_obavestenja`
--

CREATE TABLE `acp_obavestenja` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_logs`
--

CREATE TABLE `admin_logs` (
  `id` int(11) NOT NULL,
  `var1` varchar(100) NOT NULL,
  `var2` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `b_servers`
--

CREATE TABLE `b_servers` (
  `id` int(11) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `razlog` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `type` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `community`
--

CREATE TABLE `community` (
  `id` int(11) NOT NULL,
  `rank_pts` float(10,6) NOT NULL DEFAULT '0.000000',
  `naziv` varchar(30) NOT NULL,
  `forum` varchar(50) NOT NULL,
  `opis` text NOT NULL,
  `owner` varchar(30) NOT NULL,
  `ownerid` varchar(30) NOT NULL,
  `maxslots` varchar(30) NOT NULL DEFAULT '0',
  `playercount` varchar(1000) NOT NULL DEFAULT '000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000',
  `chart_updates` varchar(64) NOT NULL DEFAULT '|00|00|00|00|00|00|00|00|00|00|00|00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `community`
--

INSERT INTO `community` (`id`, `rank_pts`, `naziv`, `forum`, `opis`, `owner`, `ownerid`, `maxslots`, `playercount`, `chart_updates`) VALUES
(1, 0.000000, 'Teen Wolf Community', 'www.tw-cs.info', 'CS 1.6 Gaming zajednica.\r\nNas cilj je prikupiti CS Igrace da ozivimo igru.\r\nUkoliko zelite boost, posetite nas forum.', 'TWcs', '4', '', '000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,', '|00|02|04|06|08|10|12|14|16|18|20|22'),
(2, 0.000000, '725633', 'https://cbdoilamericano.com/', 'charlotte web cbd oil <a href=\"https://cbdoilamericano.com/\">cbd oil online</a> | <a href=\" https://cbdoilamericano.com/ \">cbd flower</a> | <a href=https://cbdoilamericano.com/>cbd book distributors</a> <a href=https://cbdoilamericano.com/>cbd oil</a>', 'assibraIncimb', '6', '', '000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,', '|17|19|21|23|01|03|05|07|09|11|13|15'),
(3, 0.000000, '217335', 'https://cbdoilamericano.com/', '<a href=\"https://cbdoilamericano.com/\">cbd oil in canada</a> | <a href=\" https://cbdoilamericano.com/ \">leafwize cbd oil</a> | https://cbdoilamericano.com/ - where to buy cbd cream', 'assibraIncimb', '6', '', '000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,', '|07|09|11|13|15|17|19|21|23|01|03|05'),
(4, 0.000000, '486688', 'https://isotretinoin.ooo/ ', '<a href=\" https://isotretinoin.ooo/ \">isotretinoin side effects</a> ', 'Janeevete', '7', '', '000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,', '|21|23|01|03|05|07|09|11|13|15|17|19');

-- --------------------------------------------------------

--
-- Table structure for table `community_servers`
--

CREATE TABLE `community_servers` (
  `id` int(11) NOT NULL,
  `comid` varchar(30) NOT NULL,
  `srvid` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `maps`
--

CREATE TABLE `maps` (
  `id` int(11) NOT NULL,
  `sid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `num` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maps`
--

INSERT INTO `maps` (`id`, `sid`, `name`, `num`) VALUES
(1, '1', 'de_dust2_xmas', '2'),
(2, '2', 'de_inferno', '11'),
(3, '3', 'zm_fortuna', '8'),
(4, '4', 'de_dust2_long', '42'),
(5, '5', 'jail_poseidon', '2'),
(6, '2', 'cs_assault_upc', '3'),
(7, '3', 'zm_defense', '6'),
(8, '5', 'jail_facebook', '1'),
(9, '2', 'de_dust2_night', '7'),
(10, '3', 'zm_five', '7'),
(11, '4', 'de_dust2', '22'),
(12, '3', 'zm_dust2_final', '6'),
(13, '2', 'de_dust_castle', '6'),
(14, '2', 'de_westwood', '17'),
(15, '2', 'cs_assault', '4'),
(16, '2', 'de_dust2', '15'),
(17, '2', 'de_dust2002', '4'),
(18, '3', 'zm_foda', '7'),
(19, '4', 'fy_snow', '13'),
(20, '3', 'zm_cross', '5'),
(21, '2', 'de_dust2_2006', '6'),
(22, '4', 'fy_inferno_x1', '1'),
(23, '2', 'de_dust4', '3'),
(24, '4', 'de_dust2_long_winter', '2'),
(25, '4', 'de_dust2_2x2', '33'),
(26, '3', 'de_dust2', '4'),
(27, '4', 'fy_snow2009', '1'),
(28, '2', 'de_mirage', '4'),
(29, '2', 'de_dust4ever', '9'),
(30, '2', 'de_dust_kry', '2'),
(31, '3', 'zm_ice_attack3', '3'),
(32, '6', 'Blood School', '5'),
(33, '7', 'San Andreas', '1'),
(34, '4', 'de_dust2x2', '3'),
(35, '6', 'San Andreas', '4'),
(36, '6', 'Los Santos', '4'),
(37, '4', 'de_nuke', '2'),
(38, '8', 'de_dust2_2x2', '8'),
(39, '8', 'de_nuke', '18'),
(40, '8', 'de_dust2', '20'),
(41, '4', 'dE_mini_dust', '3'),
(42, '8', 'de_inferno', '21'),
(43, '3', 'de_inferno', '4'),
(44, '8', 'de_train', '25'),
(45, '3', 'jail_poseidon', '3'),
(46, '2', 'de_dust2_2x2_winter16', '3'),
(47, '3', 'jail_westwood', '3'),
(48, '2', 'de_dust2_xmas', '4'),
(49, '2', 'de_nuke_winter16', '3'),
(50, '2', 'de_dust_winter16', '3'),
(51, '10', 'zm_atix_helicopter_rt', '5'),
(52, '12', 'zm_glass_attack6', '7'),
(53, '13', 'de_dust2', '12'),
(54, '9', 'de_dust2', '36'),
(55, '11', 'jail_oyunhavuzu', '5'),
(56, '12', 'zm_snow_vk6', '2'),
(57, '13', 'de_aztec', '9'),
(58, '10', 'ze_parkour_fabi_warz', '1'),
(59, '2', 'de_xmasdust', '2'),
(60, '12', 'zm_fox', '12'),
(61, '10', 'ze_destruccion_final', '6'),
(62, '11', 'jail_buyukisyan_dark', '6'),
(63, '2', 'aim_xmas', '4'),
(64, '12', 'zm_foda', '18'),
(65, '10', 'ze_underground_v2', '2'),
(66, '13', 'de_cache', '2'),
(67, '11', 'jail_buyukisyan_v8', '7'),
(68, '13', 'de_tuscan', '3'),
(69, '10', 'ze_nuke_b3', '1'),
(70, '9', 'de_alexandra', '10'),
(71, '11', 'deathrun_simple', '3'),
(72, '13', 'de_nuke', '13'),
(73, '10', 'ze_boatescape_b5', '1'),
(74, '2', 'xmas_nipperhouse', '1'),
(75, '9', 'de_mirage', '1'),
(76, '10', 'ze_ffvii_mako_reactor_s2', '3'),
(77, '2', 'fy_snow_2016', '5'),
(78, '12', 'zm_snow_volta', '4'),
(79, '10', 'ze_jurassicpark4', '10'),
(80, '2', 'de_dust2_winter16', '3'),
(81, '11', 'fy_iceworld16', '8'),
(82, '10', 'ze_fusion_dg_b5', '4'),
(83, '12', 'zm_snow_vk3', '3'),
(84, '10', 'ze_laboratorio_vhe_s6', '3'),
(85, '2', 'xmas_crazytank', '3'),
(86, '13', 'de_spay', '2'),
(87, '12', 'zm_trakinax_tubo', '6'),
(88, '10', 'ze_toxicwater_wwarz', '7'),
(89, '9', 'de_verso', '1'),
(90, '2', 'cs_whiteXmas', '2'),
(91, '13', 'de_kabul', '2'),
(92, '12', 'zm_fox_v3', '8'),
(93, '11', 'awp_katkat', '2'),
(94, '13', 'de_scrap', '1'),
(95, '9', 'de_agrena', '6'),
(96, '2', 'cs_snowflake', '2'),
(97, '11', 'fy_snow', '1'),
(98, '15', 'de_inferno', '2'),
(99, '14', 'de_nuke', '2'),
(100, '13', 'de_inferno', '7'),
(101, '11', 'awp_india', '1'),
(102, '15', 'de_train', '2'),
(103, '14', 'de_dust2', '1'),
(104, '13', 'de_cpl_mill', '1'),
(105, '12', 'zm_gbox5', '6'),
(106, '10', 'ze_xmas_escape_b2', '6'),
(107, '9', 'de_abaddon', '5'),
(108, '11', 'de_dust2_long', '3'),
(109, '14', 'de_train', '1'),
(110, '13', 'de_aztlan', '1'),
(111, '10', 'ze_atix_panic_v1', '4'),
(112, '10', 'ze_jurasikpark3_lg', '2'),
(113, '11', 'deathrun_temple', '9'),
(114, '13', 'de_mirage', '8'),
(115, '10', 'ze_assault_escape3_b3', '3'),
(116, '9', 'de_chateau', '1'),
(117, '6', 'PGaming', '3'),
(118, '15', 'noz_ultra', '1'),
(119, '13', 'de_strive', '3'),
(120, '12', 'zm_egypt_v3', '2'),
(121, '10', 'ze_prisonbreak_b3', '6'),
(122, '10', 'de_westwood', '1'),
(123, '12', 'zm_gbox6', '10'),
(124, '9', 'de_nuke', '9'),
(125, '11', 'de_dust2', '6'),
(126, '16', 'cs_assault_1337', '16'),
(127, '15', 'de_nuke', '1'),
(128, '14', 'de_isolation', '1'),
(129, '12', 'zm_snow_vk', '2'),
(130, '10', 'ze_jurassicpark_a1', '8'),
(131, '16', 'de_dust2', '20'),
(132, '10', 'ze_ice4cap_lg', '5'),
(133, '9', 'de_piranesi', '1'),
(134, '16', 'de_dust4ever', '6'),
(135, '13', 'de_austria', '1'),
(136, '12', 'zm_ice_attack3', '18'),
(137, '9', 'de_aztec', '5'),
(138, '10', 'ze_fortressv2_pg2', '4'),
(139, '20', 'afk_6killer', '2'),
(140, '18', 'de_dust2', '2'),
(141, '19', 'fy_snow', '15'),
(142, '17', 'de_dust2_2x2', '31'),
(143, '9', 'de_cbble', '2'),
(144, '17', 'de_inferno', '13'),
(145, '19', 'aim_crazyjump', '10'),
(146, '13', 'de_karachi', '1'),
(147, '1', 'de_dust2', '7'),
(148, '17', 'de_dust2', '15'),
(149, '19', 'fy_pool_day', '3'),
(150, '13', 'de_rwa', '5'),
(151, '10', 'ze_watery_escape_v1', '3'),
(152, '1', 'de_inferno', '6'),
(153, '16', 'de_nuke2x2', '3'),
(154, '19', 'aim_headshot', '8'),
(155, '13', 'de_dust', '1'),
(156, '10', 'ze_catacombs_b5', '5'),
(157, '1', 'de_nuke', '4'),
(158, '19', 'aim_map', '6'),
(159, '13', 'de_king', '2'),
(160, '10', 'ze_black_hawk_v1', '5'),
(161, '9', 'de_train', '1'),
(162, '11', 'jail_buyukisyan_v2', '1'),
(163, '1', 'de_train', '6'),
(164, '17', 'de_inferno_2x2', '34'),
(165, '12', 'zm_ice_devil2', '5'),
(166, '1', 'de_dust2x2', '2'),
(167, '19', 'awp_india', '21'),
(168, '8', 'de_dust2_long', '1'),
(169, '13', 'de_westwood', '8'),
(170, '13', 'de_cbble', '4'),
(171, '12', 'zm_csbd_vk', '3'),
(172, '13', 'de_reliquia', '1'),
(173, '10', 'ze_house_v1', '1'),
(174, '9', 'de_priest', '1'),
(175, '16', 'de_aztec_1337', '2'),
(176, '13', 'de_overpass', '2'),
(177, '12', 'zm_ice_vk', '2'),
(178, '16', 'cs_italy', '1'),
(179, '19', 'awp_skok', '5'),
(180, '12', 'zm_fox_v2', '5'),
(181, '11', 'jail_buyukisyan_v1', '3'),
(182, '16', 'cs_assault_mega', '2'),
(183, '19', '35hp_2', '2'),
(184, '13', 'de_vertigo', '1'),
(185, '10', 'ze_turkcity_wwarz_v4', '3'),
(186, '9', 'de_abbey', '1'),
(187, '19', 'aim_ak-colt', '1'),
(188, '12', 'zm_cross', '3'),
(189, '10', 'ze_freezy_xmas_b3', '1'),
(190, '16', 'de_westwood3', '5'),
(191, '13', 'de_terror', '1'),
(192, '12', 'zm_dust_attack4', '7'),
(193, '13', 'de_faction', '1'),
(194, '10', 'ze_bloodcastle_remake_s5', '1'),
(195, '9', 'de_dust2002', '5'),
(196, '16', 'de_dust2_1337', '1'),
(197, '13', 'de_losttemple', '1'),
(198, '16', 'de_perfect_inferno', '1'),
(199, '13', 'de_reallite', '1'),
(200, '17', 'de_aztec_0', '1'),
(201, '13', 'de_guardian', '1'),
(202, '10', 'ze_fearless_final_wwarz', '4'),
(203, '9', 'de_barcelona', '2'),
(204, '16', 'de_dust2ro', '1'),
(205, '8', 'jail_galaxy', '1'),
(206, '4', 'de_dust2x2_sneg', '2'),
(207, '16', 'de_aztec_remake', '1'),
(208, '8', 'jail_anka_v1', '2'),
(209, '7', 'Elite Community', '2'),
(210, '10', 'ze_blackmesa_v9', '6'),
(211, '8', 'jail_especial_v2', '1'),
(212, '19', 'aim_scout', '19'),
(213, '8', 'jail_facebook', '1'),
(214, '16', 'de_dust', '10'),
(215, '12', 'zm_str_vk2', '1'),
(216, '16', 'de_westwood_big', '2'),
(217, '19', 'de_clan1_mill', '1'),
(218, '8', 'jail_atari', '1'),
(219, '12', 'zm_adytzasfantu', '3'),
(220, '19', 'de_dust', '1'),
(221, '13', 'de_dust4never', '3'),
(222, '8', 'de_westwood', '1'),
(223, '13', 'de_severe', '2'),
(224, '12', 'zm_ugc2', '1'),
(225, '16', 'de_aztec_0', '2'),
(226, '13', 'de_dangel', '2'),
(227, '10', 'ze_thelostworld', '6'),
(228, '9', 'de_inferno', '6'),
(229, '16', 'de_dust2002', '2'),
(230, '13', 'de_fact', '1'),
(231, '10', 'ze_isla_nublar_lg', '4'),
(232, '13', 'de_invictus', '1'),
(233, '4', 'de_dust2_2x2_winter16', '2'),
(234, '16', 'de_cbble', '2'),
(235, '19', 'aim_paper', '9'),
(236, '21', 'de_wraith', '1'),
(237, '10', 'ze_jurassicpark2_s3', '3'),
(238, '19', 'fy_baddust', '15'),
(239, '21', 'fy_snow', '11'),
(240, '9', 'de_westwood', '3'),
(241, '16', 'de_westwood', '2'),
(242, '21', 'de_dust2', '9'),
(243, '11', 'jail_patos', '1'),
(244, '16', 'de_dust2_2006', '4'),
(245, '12', 'zm_x1', '5'),
(246, '21', 'de_inferno', '12'),
(247, '10', 'ze_simple_extra_wwarz', '4'),
(248, '9', 'de_rwa_rc1', '3'),
(249, '13', 'de_assault', '1'),
(250, '11', 'jail_pixel_kar', '1'),
(251, '21', 'de_alexandra', '1'),
(252, '13', 'de_railroadstar', '1'),
(253, '12', 'zm_sand', '1'),
(254, '10', 'zm_assaultescape_warz_lg', '6'),
(255, '21', 'de_cbble', '3'),
(256, '10', 'zm_isla_escape_warz', '3'),
(257, '4', 'cs_assault', '2'),
(258, '21', 'cs_deagle5', '1'),
(259, '13', 'de_cloister', '1'),
(260, '11', 'jail_buyukisyan_yilbasi2', '1'),
(261, '16', 'de_nuke', '2'),
(262, '2', 'x-mas_tree', '2'),
(263, '13', 'de_stoned', '1'),
(264, '21', 'de_aztec_0', '3'),
(265, '13', 'de_agrena', '3'),
(266, '11', 'big_city2', '2'),
(267, '19', 'fy_out', '11'),
(268, '13', 'de_online', '1'),
(269, '12', 'zm_tonga', '2'),
(270, '21', 'de_chateau', '1'),
(271, '13', 'de_chateau', '1'),
(272, '10', 'ze_jurassickpark4_warz', '3'),
(273, '9', 'de_clan1_mill_32', '1'),
(274, '21', 'de_cbbl2', '2'),
(275, '22', 'bb_classic_iplay', '9'),
(276, '9', 'de_larocca_beta', '1'),
(277, '16', 'de_westwood_newstyle', '5'),
(278, '22', 'bb_dust_s1', '1'),
(279, '23', 'jail_pyramid', '6'),
(280, '21', 'de_nuke', '7'),
(281, '22', 'bb_confidence_castle_v10', '5'),
(282, '12', 'zm_extend', '1'),
(283, '2', 'de_dust2_2x2', '2'),
(284, '3', '35hp_2', '5'),
(285, '22', 'bb_castle_final', '2'),
(286, '5', 'de_dust2', '2'),
(287, '23', 'jail_facebook', '3'),
(288, '10', 'ze_force_heights_fixed', '2'),
(289, '21', 'de_westwood_big', '1'),
(290, '22', 'bb_temple', '2'),
(291, '23', 'jail_anka_v1', '1'),
(292, '4', 'de_dust2_5x5', '2'),
(293, '21', 'awp_india', '4'),
(294, '22', 'bb_crete4', '4'),
(295, '23', 'jail_crime', '2'),
(296, '10', 'zm_Atix_Helicopter', '1'),
(297, '9', 'de_rds32', '1'),
(298, '22', 'bb_cg_ff_hunt_v8', '1'),
(299, '23', 'jail_alonecity_v1', '3'),
(300, '13', 'de_cbblestone', '1'),
(301, '17', 'cs_assault', '1'),
(302, '21', 'de_kgb_map', '2'),
(303, '22', 'bb_india_night', '2'),
(304, '23', 'jail_oyunhavuzu', '1'),
(305, '13', 'de_storm2', '1'),
(306, '21', 'de_clan3_heat', '1'),
(307, '3', '1hp_just', '1'),
(308, '21', 'de_inferno_2x2', '1'),
(309, '2', 'de_nuke', '9'),
(310, '22', 'bb_ancient_toxic', '9'),
(311, '3', '35hp_alone', '2'),
(312, '16', 'cs_assault_rush', '2'),
(313, '19', 'fy_buzzkill', '1'),
(314, '22', 'bb_avatar_final', '8'),
(315, '13', 'de_spree', '1'),
(316, '16', 'de_dust_winter16', '3'),
(317, '21', 'de_apocalypse', '1'),
(318, '22', 'bb_dust2_winter', '4'),
(319, '23', 'jail_freedom_fix', '1'),
(320, '13', 'de_kosova', '2'),
(321, '8', 'awp_india', '1'),
(322, '3', '35hp_2house', '4'),
(323, '9', 'de_dust2x2', '2'),
(324, '22', 'bb_revenge_dust', '8'),
(325, '21', 'de_tuscan', '1'),
(326, '13', 'de_afghan', '1'),
(327, '12', 'zm_dusts_winter', '1'),
(328, '16', 'de_dust2_winter16', '2'),
(329, '21', 'de_spay', '2'),
(330, '3', '35hp_dustzone', '6'),
(331, '10', 'ze_campescape_b1', '3'),
(332, '21', 'de_munze', '2'),
(333, '22', 'bb_cg_hard_base_v4', '4'),
(334, '3', 'ze_area51_v1', '1'),
(335, '9', 'de_hell_32', '1'),
(336, '17', 'de_nuke32_2x2', '1'),
(337, '3', 'ze_ice4cap_lg', '1'),
(338, '23', 'jail_buyukisyan_dark', '1'),
(339, '21', 'de_dust', '1'),
(340, '22', 'bb_godlike_gr_base', '6'),
(341, '3', 'ze_campescape_lg', '1'),
(342, '13', 'de_scorpions', '2'),
(343, '21', 'de_hell', '2'),
(344, '22', 'bb_death_bridge', '3'),
(345, '3', 'de_nuke', '1'),
(346, '10', 'ze_sectorbg_fix4', '2'),
(347, '16', 'lethal_de_dust2_mirror', '1'),
(348, '22', 'bb_inferno_iplay', '10'),
(349, '23', 'jail_darkcity_v1', '1'),
(350, '16', 'de_mirage', '2'),
(351, '8', 'fy_snow', '4'),
(352, '23', 'jail_westwood', '1'),
(353, '13', 'de_hell', '2'),
(354, '10', 'ze_hospital_warz', '3'),
(355, '21', 'css_cache', '2'),
(356, '16', 'fy_snow_orange', '2'),
(357, '3', 'ze_area51_lg', '1'),
(358, '4', 'cs_assault_mini', '2'),
(359, '13', 'de_valpo2', '1'),
(360, '21', 'de_train', '4'),
(361, '23', 'jail_xmf', '2'),
(362, '13', 'de_antishock', '2'),
(363, '12', 'zm_snowbase4_zp', '1'),
(364, '21', 'de_prodigy', '1'),
(365, '22', 'bb_aztec_s1', '2'),
(366, '13', 'de_torn', '2'),
(367, '21', 'de_scud', '2'),
(368, '22', 'bb_infantry', '1'),
(369, '9', 'cs_office', '2'),
(370, '23', 'jail_darkover', '1'),
(371, '12', 'zm_long_glass', '2'),
(372, '10', 'ze_escapecity_wwarz_s2', '2'),
(373, '13', 'de_train', '4'),
(374, '22', 'bb_dust2_sandania', '1'),
(375, '21', 'de_dust2002', '2'),
(376, '23', 'fy_snow', '8'),
(377, '3', '35hp_step', '3'),
(378, '13', 'de_bunker2', '1'),
(379, '11', 'deathrun_extreme', '2'),
(380, '16', 'cs_assault_shadow', '1'),
(381, '3', '35hp_stylishdust', '4'),
(382, '12', 'zm_ibero', '1'),
(383, '21', 'css_overpass', '1'),
(384, '10', 'ze_jurassicpark_v2_warz', '1'),
(385, '21', 'de_westwood', '1'),
(386, '21', 'de_c-market', '1'),
(387, '24', 'de_inferno', '2'),
(388, '21', 'de_irak', '2'),
(389, '22', 'bb_autumn', '4'),
(390, '24', 'de_train', '2'),
(391, '12', 'zm_pacman', '4'),
(392, '24', 'de_nuke', '1'),
(393, '21', 'de_mirage', '2'),
(394, '16', 'cs_assault', '1'),
(395, '3', '35hp_cbble_v2', '1'),
(396, '23', 'de_dust2_snow', '7'),
(397, '10', 'ze_kabul_b3', '1'),
(398, '16', 'css_dust2', '4'),
(399, '16', 'css_nuke_rarea', '1'),
(400, '3', '35hp_buildsite', '2'),
(401, '13', 'de_fpg', '1'),
(402, '16', 'css_nuke', '3'),
(403, '23', 'de_dust2_2x2', '14'),
(404, '13', 'de_chapter', '1'),
(405, '12', 'zm_ice_csd', '1'),
(406, '16', 'de_aztec', '4'),
(407, '8', 'fy_pool_Day', '1'),
(408, '21', 'de_nuke_rarea', '1'),
(409, '9', 'de_cache', '1'),
(410, '16', 'css_aztec', '2'),
(411, '11', 'de_dust', '1'),
(412, '1', 'deathrun_arctic', '2'),
(413, '21', 'de_cup2', '1'),
(414, '23', 'de_dust2_long', '4'),
(415, '3', 'de_train', '1'),
(416, '25', 'Los Santos', '2'),
(417, '9', 'de_c4', '1'),
(418, '13', 'de_militia', '1'),
(419, '13', 'de_indust', '1'),
(420, '21', 'cs_assault', '4'),
(421, '9', 'de_dust2_china', '1'),
(422, '13', 'de_santorini', '1'),
(423, '13', 'de_entra', '1'),
(424, '12', 'zm_aztec_sdl_v1', '1'),
(425, '10', 'ze_highmountain_wwarz_v1', '1'),
(426, '21', 'de_barcelona', '1'),
(427, '13', 'de_anomalous', '1'),
(428, '10', 'ze_atix_assault', '3'),
(429, '21', 'de_energy', '1'),
(430, '25', 'San Andreas', '2'),
(431, '16', 'css_mirage_go', '4'),
(432, '22', 'bb_tutankhamun_lite', '1'),
(433, '13', 'de_dolc', '1'),
(434, '10', 'ze_mars1_pg', '2'),
(435, '11', 'deathrun_ice', '1'),
(436, '13', 'de_arcadian', '1'),
(437, '16', 'de_dust2_2018', '3'),
(438, '23', 'de_inferno', '2'),
(439, '21', 'de_oldk_dust', '1'),
(440, '13', 'de_monotonous2', '2'),
(441, '13', 'de_autumn', '1'),
(442, '12', 'zm_inferno_small_fix', '1'),
(443, '21', 'de_dustyaztec', '1'),
(444, '16', 'de_dust2_hdservers', '3'),
(445, '9', 'de_austria', '1'),
(446, '13', 'de_breakdown', '1'),
(447, '11', 'surf_ski_2', '2'),
(448, '26', 'de_dust2', '3'),
(449, '22', 'bb_ff_hunt_v5', '2'),
(450, '26', 'de_dust2_2x2', '2'),
(451, '9', 'de_free32', '1'),
(452, '13', 'de_stern', '1'),
(453, '12', 'zm_fortuna', '1'),
(454, '16', 'cs_newbassault', '1'),
(455, '13', 'de_plaka', '1'),
(456, '21', 'de_inferno2se', '1'),
(457, '26', 'Noz_ultra', '1'),
(458, '13', 'de_salt2', '1'),
(459, '13', 'de_vine', '1'),
(460, '12', 'zm_2day', '1'),
(461, '21', 'de_italy', '1'),
(462, '16', 'css_inferno2x2', '1'),
(463, '4', 'de_dust2_long_2012', '3'),
(464, '27', 'de_dust2', '2'),
(465, '9', 'de_berzerker', '1'),
(466, '13', 'de_construct', '1'),
(467, '28', 'de_dust2', '4'),
(468, '9', 'de_dust4_32', '1'),
(469, '13', 'de_airstrip', '1'),
(470, '8', 'de_rats', '2'),
(471, '28', 'de_inferno', '3'),
(472, '26', 'fy_snow', '1'),
(473, '28', 'de_dustyaztec', '1'),
(474, '9', 'de_2minaret', '1'),
(475, '13', 'de_havana', '1'),
(476, '13', 'de_iced', '1'),
(477, '12', 'zm_snow_mix', '1'),
(478, '18', 'de_nuke', '1'),
(479, '22', 'bb_dust2015', '1');

-- --------------------------------------------------------

--
-- Table structure for table `messages_answers`
--

CREATE TABLE `messages_answers` (
  `id` int(11) NOT NULL,
  `mid` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `obavestenja`
--

CREATE TABLE `obavestenja` (
  `id` int(11) NOT NULL,
  `var` text NOT NULL,
  `nza` varchar(100) NOT NULL,
  `nod` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obavestenja`
--

INSERT INTO `obavestenja` (`id`, `var`, `nza`, `nod`, `time`, `status`, `type`) VALUES
(1, '2', '', '1', '1541326737', '0', '1'),
(2, '4', '', '2', '1541879063', '0', '1'),
(3, '/member/Bogoljub', '2', '1', '1541884363', '1', '2');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `score` varchar(10) NOT NULL,
  `time_online` varchar(50) NOT NULL,
  `mapname` varchar(50) NOT NULL,
  `sid` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `nickname`, `score`, `time_online`, `mapname`, `sid`) VALUES
(1363106, '----------------------', '0', '122.25091552734', 'de_inferno', '28'),
(1363099, 'aci jak', '19', '810.59027099609', 'de_inferno', '28'),
(1363100, 'BCB Soldier', '8', '754.46166992188', 'de_inferno', '28'),
(1363101, 'jokerdragomije', '5', '753.45111083984', 'de_inferno', '28'),
(1363102, '(3)<Warrior> Player', '2', '752.61572265625', 'de_inferno', '28'),
(1363103, 'gazsi gyilkos123', '11', '739.01904296875', 'de_inferno', '28'),
(1363104, 'na la pula na la pula', '22', '737.71691894531', 'de_inferno', '28'),
(1363105, 'veno34225671', '9', '730.75616455078', 'de_inferno', '28'),
(1363098, 'Kosovo Srbija', '11', '821.98223876953', 'de_inferno', '28'),
(1363097, 'B.S.U. 06', '21', '955.64611816406', 'de_inferno', '28'),
(1363096, 'Forrest Gump 3pm.', '19', '350.07809448242', 'de_inferno', '28'),
(1363095, 'ThE BeAsT', '30', '998.50311279297', 'de_inferno', '28'),
(1363094, 'koko', '30', '439.77560424805', 'de_inferno', '28'),
(1363093, 'a', '6', '941.22863769531', 'de_inferno', '28'),
(1363092, 'LOTT@', '5', '86.709365844727', 'de_inferno', '28'),
(1363078, 'Dodajte ovaj server u favorite', '0', '1205591.5', 'de_dust2', '8'),
(1363077, '5e = Admin', '0', '1205591.5', 'de_dust2', '8'),
(1363076, 'taz [Karigan <3 awp 4 dfq.', '0', '34.109134674072', 'de_dust2', '26'),
(1363075, 'BULEVARAC', '1', '117.52297210693', 'de_dust2', '26'),
(1363074, '[AssAsiAns] Skole', '3', '872.73297119141', 'de_dust2', '26'),
(1363073, 'laganezzi', '13', '7686.1376953125', 'de_dust2', '26'),
(1363072, 'SkAz!!!', '4', '987.34387207031', 'de_dust2', '26'),
(1363045, 'ï¼ƒRUSSIAN CFG v1 by aXE', '0', '1003.0337524414', 'de_dust2_snow', '23'),
(1363023, 'EuroPlayer', '0', '718.45739746094', 'bb_cg_ff_hunt_v8', '22'),
(1363022, 'Kovaqiiii*', '4', '772.265625', 'bb_cg_ff_hunt_v8', '22'),
(1363021, 'xXMaster5Xx', '8', '525.72174072266', 'bb_cg_ff_hunt_v8', '22'),
(1362950, 'Rama`BiTANGA', '0', '2050.7531738281', 'de_dust2', '21'),
(1362951, 'tuklord', '0', '84.966133117676', 'de_dust2', '21'),
(1362952, 'Raptile.', '0', '519.56549072266', 'de_dust2', '21'),
(1362953, '=*flash*=', '5', '254.75416564941', 'de_dust2', '21'),
(1362954, 'hift', '0', '835.3955078125', 'de_dust2', '21'),
(1362955, 'Dejana <3 marE.', '0', '1795.2374267578', 'de_dust2', '21'),
(1362956, 'scekara', '1', '300.53900146484', 'de_dust2', '21'),
(1362957, 'dr.Red', '8', '197.24462890625', 'de_dust2', '21'),
(1362958, 'ZeKa BrAnI KrUsEvAc', '3', '184.48728942871', 'de_dust2', '21'),
(1362959, '/AcceSS DenIeD/', '0', '351.15374755859', 'de_dust2', '21'),
(1362960, 'TrsHInoo\'\'', '3', '141.86492919922', 'de_dust2', '21'),
(1362961, 'ARSNL', '0', '167.26037597656', 'de_dust2', '21'),
(1362962, 'Caja', '0', '161.65240478516', 'de_dust2', '21'),
(1362992, 'SPRYZEN VALTRIEK:)))', '0', '175.54870605469', 'de_dust2_2018', '16'),
(1362993, '=KrWzZ', '0', '165.77993774414', 'de_dust2_2018', '16'),
(1362994, 'MiCkO', '0', '61.340198516846', 'de_dust2_2018', '16'),
(1362995, '_RaziC', '0', '163.35050964355', 'de_dust2_2018', '16'),
(1363014, 'GT | NoAudio', '2', '1617.1555175781', 'bb_cg_ff_hunt_v8', '22'),
(1363015, '(3)<Warrior> Player', '0', '1790.5618896484', 'bb_cg_ff_hunt_v8', '22'),
(1363016, 'YouCeF PxR', '2', '1587.8438720703', 'bb_cg_ff_hunt_v8', '22'),
(1363017, 'Player', '18', '11230.971679688', 'bb_cg_ff_hunt_v8', '22'),
(1363018, 'kap0', '1', '2131.5915527344', 'bb_cg_ff_hunt_v8', '22'),
(1363019, '(1)<Warrior> Player', '0', '2742.1105957031', 'bb_cg_ff_hunt_v8', '22'),
(1363020, 'ATiGa tunisia', '3', '416.53894042969', 'bb_cg_ff_hunt_v8', '22'),
(1363091, '100EV', '22', '869.31384277344', 'de_inferno', '28'),
(1363034, 'Mr.D', '0', '114.99993133545', 'bb_cg_ff_hunt_v8', '22'),
(1363033, '[ZM PLAY-ARENA RO][5]', '0', '658.91528320312', 'bb_cg_ff_hunt_v8', '22'),
(1363032, 'jetpack', '0', '112.16698455811', 'bb_cg_ff_hunt_v8', '22'),
(1363031, 'shakall', '6', '1024.5593261719', 'bb_cg_ff_hunt_v8', '22'),
(1363030, 'panapan61', '0', '118.69625854492', 'bb_cg_ff_hunt_v8', '22'),
(1363029, '[NaJJaCi^-^] ProLtgraYiCa <3ï¼ƒ', '0', '178.72581481934', 'bb_cg_ff_hunt_v8', '22'),
(1363028, 'NAJJACI ^_^ DuXsa', '1', '2277.6440429688', 'bb_cg_ff_hunt_v8', '22'),
(1363027, 'AnImaLs*{T}_{i}_{Z}_{a}*', '6', '3838.8298339844', 'bb_cg_ff_hunt_v8', '22'),
(1363026, '*NIDAL     05         DZ*', '0', '125.65991210938', 'bb_cg_ff_hunt_v8', '22'),
(1363025, 'Aycan', '0', '924.71710205078', 'bb_cg_ff_hunt_v8', '22'),
(1363090, 'Ar7efak7a``', '22', '369.12567138672', 'de_inferno', '28'),
(1363089, 'Another Surf Gateway Fan', '1', '1.1805114746094', 'de_inferno', '28'),
(1363088, 'E[T]ernal-99', '33', '1147.7358398438', 'de_inferno', '28'),
(1363087, 'Smell', '20', '1524.2873535156', 'de_inferno', '28'),
(1363086, 'RagNaR', '26', '1016.6940917969', 'de_inferno', '28'),
(1363085, 'S.W.A.T.', '5', '80.408447265625', 'de_inferno', '28'),
(1363084, 'TPAKTOPA', '28', '897.71417236328', 'de_inferno', '28'),
(1363083, 'Hard Target', '22', '455.37420654297', 'de_inferno', '28'),
(1363082, '[IP] 93.123.18.82:27016', '7', '90681.6328125', 'de_inferno', '28'),
(1363081, 'szarhazi4', '5', '1583.1905517578', 'de_inferno', '28'),
(1363080, 'Midnight+ï¸´oker~', '26', '399.076171875', 'de_inferno', '28'),
(1363079, 'WEB: LAN-BG.INFO', '0', '90681.6328125', 'de_inferno', '28'),
(1362949, 'Da A !?! |SRB|', '4', '142.33682250977', 'de_dust2', '21'),
(1362948, 'umoci keks u mleko // CZV', '0', '486.39672851562', 'de_dust2', '21'),
(1362947, 'TS3: fatality-ts3', '0', '34074.01953125', 'de_dust2', '21'),
(1362946, 'www.fatality-cs.info', '0', '34074.01953125', 'de_dust2', '21'),
(1362945, 'BELI', '0', '2247.859375', 'de_dust2', '21'),
(1362944, 'FesSta', '0', '615.78784179688', 'de_dust2', '21'),
(1362943, 'SCANDERBEG', '0', '4080.5129394531', 'de_dust2', '21'),
(1362941, 'Legionnaire', '0', '11.658658027649', 'de_dust2', '21'),
(1362942, 'vviLdENNN 4 Katarina Grujic', '1', '1232.6717529297', 'de_dust2', '21'),
(1362940, 'ro0kie.', '0', '5338.744140625', 'de_dust2', '21'),
(1362939, 'Slim Shady', '0', '2038.9132080078', 'de_dust2', '21'),
(1362938, 'BD ELECTRON', '5', '258.26599121094', 'de_dust2', '21'),
(1362937, 'Superb', '1', '1467.8110351562', 'de_dust2', '21'),
(1362936, 'Srdzan', '1', '585.24493408203', 'de_dust2', '21'),
(1362911, 'Fed0R(bp)', '12', '3837.5942382812', 'de_rust', '13'),
(1362910, 'USP ._.', '8', '611.28625488281', 'de_rust', '13'),
(1362909, '407K057b 736484', '0', '6695.9624023438', 'de_rust', '13'),
(1362908, '__::HPB::__<<h0lzed.pro>>', '20', '2279.3210449219', 'de_rust', '13'),
(1362891, 'KapATe/lb', '2', '1918.3114013672', 'de_rust', '13'),
(1362892, 'vova kamposter', '5', '1798.4133300781', 'de_rust', '13'),
(1362893, 'Extra Classic [Russia]', '22', '1324.0330810547', 'de_rust', '13'),
(1362894, 'iExcuseMe', '4', '2917.9182128906', 'de_rust', '13'),
(1362895, 'AIM', '0', '806.16137695312', 'de_rust', '13'),
(1362896, 'Gre4ka', '3', '5294.1127929688', 'de_rust', '13'),
(1362897, '500 za', '22', '861.87420654297', 'de_rust', '13'),
(1362898, 'Chuvash', '5', '510.28253173828', 'de_rust', '13'),
(1362899, 'JONNY 4EKIST iz DONECKA', '2', '329.90139770508', 'de_rust', '13'),
(1362900, 'evil', '6', '1545.1120605469', 'de_rust', '13'),
(1362901, 'Poly4i', '0', '100.83475494385', 'de_rust', '13'),
(1362902, 'Pro3peHue', '2', '196.86302185059', 'de_rust', '13'),
(1362903, 'L.A.', '0', '34.735931396484', 'de_rust', '13'),
(1362904, '001', '4', '859.33459472656', 'de_rust', '13'),
(1362905, 'Chapayonok163Rus', '0', '351.50189208984', 'de_rust', '13'),
(1362906, '3arpagoTp9g', '4', '351.95297241211', 'de_rust', '13'),
(1362907, '013', '5', '1366.7670898438', 'de_rust', '13'),
(1363007, 'Forums: Khan-cs.mojkgb.com', '0', '35995.1484375', 'de_dust2', '18'),
(1363008, '[WELLCOME TO PROHUNTER BB]', '0', '18020.75390625', 'bb_cg_ff_hunt_v8', '22'),
(1363009, '[ADD IP TO FAVORITES]', '0', '18020.75390625', 'bb_cg_ff_hunt_v8', '22'),
(1363010, 'Special1One', '0', '81.881637573242', 'bb_cg_ff_hunt_v8', '22'),
(1363011, '.sApOvitCh^DogliN_', '13', '598.12823486328', 'bb_cg_ff_hunt_v8', '22'),
(1363012, 'abdou', '0', '775.16125488281', 'bb_cg_ff_hunt_v8', '22'),
(1363005, 'General Quakforce', '23', '2009.6099853516', 'de_inferno_2x2', '17'),
(1363004, 'PoinT', '17', '745.62481689453', 'de_inferno_2x2', '17'),
(1363003, 'Call Me Your DaD', '6', '781.58026123047', 'de_inferno_2x2', '17'),
(1363006, 'Pub Sv Ip: 193.192.58.150:27021', '0', '35995.1484375', 'de_dust2', '18'),
(1362890, 'SvOLo4', '9', '1812.7241210938', 'de_rust', '13'),
(1362889, 'der)I(al', '2', '2911.3818359375', 'de_rust', '13'),
(1362887, 'Stinky Fox', '8', '1587.7736816406', 'de_rust', '13'),
(1362888, 'Just A Little More Love', '9', '684.29083251953', 'de_rust', '13'),
(1362879, 'Bars', '2', '279.2360534668', 'de_abaddon', '9'),
(1363024, 'gametracker-lt', '12', '1669.1258544922', 'bb_cg_ff_hunt_v8', '22'),
(1362877, 'KuTaeu,', '6', '205.01174926758', 'de_abaddon', '9'),
(1362878, '``Twister', '0', '360.2956237793', 'de_abaddon', '9'),
(1362885, '[G][A][N][G][S][T][E][R]', '2', '4115.8100585938', 'de_rust', '13'),
(1362886, 'H1T :)', '6', '11826.983398438', 'de_rust', '13'),
(1362882, 'BIG.XANTARES', '4', '4677.8901367188', 'de_rust', '13'),
(1362883, 'Crossfit', '0', '108.33474731445', 'de_rust', '13'),
(1362884, '[zapovednik]GREEN-HILL ranenii', '8', '2426.2790527344', 'de_rust', '13'),
(1363044, 'ADD IP TO FAVORITES', '0', '156404.09375', 'de_dust2_snow', '23'),
(1363043, 'Neki 1.8T', '0', '852.1669921875', 'de_dust2_snow', '23'),
(1363042, 'G.H.O.S.T', '0', '430.54791259766', 'de_dust2_snow', '23'),
(1363041, 'KormiloAUS', '0', '34.482669830322', 'de_dust2_snow', '23'),
(1363040, 'Svemirski Burek', '0', '70.48876953125', 'de_dust2_snow', '23'),
(1363013, '<Warrior> Player', '0', '2761.365234375', 'bb_cg_ff_hunt_v8', '22'),
(1362991, 'paradajzzz', '0', '242.64677429199', 'de_dust2_2018', '16'),
(1362990, 'ThE EnD***', '0', '34.463111877441', 'de_dust2_2018', '16'),
(1363001, 'Forums: Khan-cs.mojkgb.com', '0', '133316.6875', 'de_inferno_2x2', '17'),
(1363002, 'SaddaM', '0', '131.24694824219', 'de_inferno_2x2', '17'),
(1362998, 'Add IP: 193.192.58.150:27021', '0', '133316.6875', 'de_inferno_2x2', '17'),
(1362989, 'Mikail', '0', '399.85583496094', 'de_dust2_2018', '16'),
(1363000, 'xt400', '7', '5443.162109375', 'de_inferno_2x2', '17'),
(1362988, 'keygen  DZ', '0', '108.56071472168', 'de_dust2_2018', '16'),
(1362979, '|K|m|S|.rs | Ñ‡Ð¸ÐºÐ° Ð¿Ñ€Ð¾Ñ„', '0', '1233.9932861328', 'de_dust2_2018', '16'),
(1362987, '|K|m|S|.rs | $aullt', '0', '400.14736938477', 'de_dust2_2018', '16'),
(1362985, 'baqir', '0', '1043.0656738281', 'de_dust2_2018', '16'),
(1362986, 'enesselim', '0', '370.38662719727', 'de_dust2_2018', '16'),
(1362984, 'Leva', '0', '794.26098632812', 'de_dust2_2018', '16'),
(1362983, '|K|m|S|.rs | Bajkos', '0', '172.43388366699', 'de_dust2_2018', '16'),
(1362982, 'Ub!C@', '0', '257.97866821289', 'de_dust2_2018', '16'),
(1362967, 'just pro', '4', '1050.8485107422', 'afk_6killer', '20'),
(1362966, 'Rick', '6', '2867.3315429688', 'afk_6killer', '20'),
(1362965, 'Forums: Khan-cs.mojkgb.com', '0', '572199.8125', 'afk_6killer', '20'),
(1362997, 'Admin + Vip 1x Boost', '0', '45592.7578125', 'de_dust2_2x2', '4'),
(1362999, '///   TNT   ///', '11', '5153.150390625', 'de_inferno_2x2', '17'),
(1362981, 'zeeko +ï½™ehya=king@sharaffffff', '0', '1082.6470947266', 'de_dust2_2018', '16'),
(1362980, 'ALYASSA_963_ARY_', '0', '1191.8029785156', 'de_dust2_2018', '16'),
(1362978, 'bosssssi', '0', '78.045951843262', 'de_dust2_2018', '16'),
(1362976, 'K|M|A|C|<HUGO>|K|M|A|C|', '0', '1208.7531738281', 'de_dust2_2018', '16'),
(1362881, 'Krujok', '9', '860.04321289062', 'de_rust', '13'),
(1362880, 'neumeu', '0', '4901.0346679688', 'de_rust', '13'),
(1362977, '. sandra Ð°Ñ„Ñ€Ð¸ÐºÐ°', '0', '1379.3160400391', 'de_dust2_2018', '16'),
(1362935, 'B', '0', '7651.7900390625', 'de_dust2', '21'),
(1362934, 'ElpamaZ.', '5', '694.94366455078', 'zm_gbox5', '12'),
(1362964, '.\'. phi phi .\'.', '0', '53.8830909729', 'afk_6killer', '20'),
(1362975, 'azden', '0', '1232.7331542969', 'de_dust2_2018', '16'),
(1362973, 'steam class and vip class free', '0', '1495.3879394531', 'de_dust2_2018', '16'),
(1362974, 'fb.com/groups/wlcmthl', '0', '1495.3879394531', 'de_dust2_2018', '16'),
(1362972, 'PitBull@', '0', '1453.1918945312', 'de_dust2_2018', '16'),
(1362933, 'Sex_Manqka', '21', '1112.1258544922', 'zm_gbox5', '12'),
(1362932, 'mokhtar dz', '11', '1306.2314453125', 'zm_gbox5', '12'),
(1362931, 'nordin ma3abla', '4', '1306.4041748047', 'zm_gbox5', '12'),
(1362930, 'Envitch.', '15', '1401.0157470703', 'zm_gbox5', '12'),
(1362929, '|RoYs|', '6', '4539.0068359375', 'zm_gbox5', '12'),
(1362928, 'DIABLO', '10', '1310.3581542969', 'zm_gbox5', '12'),
(1362927, '>>>>>FBI<<<<<', '15', '3851.9299316406', 'zm_gbox5', '12'),
(1362926, '$$mary$$', '0', '1306.9539794922', 'zm_gbox5', '12'),
(1362925, 'Chupy', '1', '267.87945556641', 'zm_gbox5', '12'),
(1362922, 'UaRe(=)', '9', '3352.5402832031', 'zm_gbox5', '12'),
(1362923, 'xLGx', '0', '1619.8229980469', 'zm_gbox5', '12'),
(1362924, '[MC]Ronin', '12', '1642.7947998047', 'zm_gbox5', '12'),
(1362963, 'Add IP: 193.192.58.150:27020', '0', '572199.8125', 'afk_6killer', '20'),
(1363039, 'ADMIN 2x BOOST; VIP 1x BOOST', '0', '156404.09375', 'de_dust2_snow', '23'),
(1363035, 'jalilo', '3', '2833.84765625', 'bb_cg_ff_hunt_v8', '22'),
(1362971, 'oops i kill you', '0', '995.18762207031', 'de_dust2_2018', '16'),
(1362970, 'Kalas nosim Botove kosim', '0', '1233.6418457031', 'de_dust2_2018', '16'),
(1362969, 'agaton', '0', '1233.6694335938', 'de_dust2_2018', '16'),
(1362968, 'ANUBIS', '0', '3.125373840332', 'de_dust2_2018', '16'),
(1362921, 'Stelistu', '31', '16828.9609375', 'zm_gbox5', '12'),
(1362875, 'Baruch', '5', '532.89599609375', 'de_abaddon', '9'),
(1362876, 'kakos', '2', '3805.9978027344', 'de_abaddon', '9'),
(1362874, '[K[o[T1]K]a]*****', '2', '918.63122558594', 'de_abaddon', '9'),
(1362873, '=AJluax=', '0', '989.99090576172', 'de_abaddon', '9'),
(1362872, 'MYP/IbIKA', '6', '4385.921875', 'de_abaddon', '9'),
(1362869, 'ï¼ƒbingo', '0', '2732.1733398438', 'de_abaddon', '9'),
(1362870, 'CS ARENA-Danilka', '4', '1805.1223144531', 'de_abaddon', '9'),
(1362871, '4ux-IIux', '2', '545.14331054688', 'de_abaddon', '9'),
(1363071, 'K-User', '0', '1240.8312988281', 'de_dust2', '26'),
(1363070, 'Nemanja', '0', '31.543550491333', 'de_dust2', '26'),
(1363069, 'Hacked', '8', '2658.6293945312', 'de_dust2', '26'),
(1363068, 'Welcome', '0', '50876.01953125', 'de_dust2', '26'),
(1363067, 'ACID | Trip*', '0', '40.913047790527', 'de_dust2', '26'),
(1363066, 'SuljaGODD prbbb', '0', '65.701034545898', 'de_dust2', '26'),
(1363065, 'Ionut', '0', '45.546199798584', 'de_dust2', '26'),
(1363064, 'pg.ba', '0', '190.12278747559', 'de_dust2', '26'),
(1363038, 'GAnja', '1', '31.551795959473', 'de_dust2_snow', '23'),
(1363036, 'ï¼ƒMedo', '0', '270.26068115234', 'de_dust2_snow', '23'),
(1363063, 'abdo gazii', '0', '34.046211242676', 'de_dust2', '26'),
(1363062, 'Potrebni admini 18+', '0', '50876.01953125', 'de_dust2', '26'),
(1363061, 'Vin Diesel', '0', '97.353485107422', 'de_dust2', '26'),
(1363060, 'jare od vuka [nub]', '4', '434.8180847168', 'de_dust2', '26'),
(1363059, 'GAME DOG', '3', '227.5655670166', 'de_dust2', '26'),
(1363058, 'anu nou', '30', '1905.8934326172', 'de_dust2', '26'),
(1363057, 'Nasenschiff', '2', '899.95971679688', 'de_dust2', '26'),
(1363056, 'miki12345', '2', '229.36161804199', 'de_dust2', '26'),
(1363055, 'P.R.L.E.', '11', '961.07733154297', 'de_dust2', '26'),
(1363054, 'Saki', '2', '1068.8582763672', 'de_dust2', '26'),
(1363052, 'whiZz ups. ãƒ„', '0', '10340.700195312', 'de_dust2', '26'),
(1363053, 'autenticni SRPSKI JUNAK', '19', '2443.8718261719', 'de_dust2', '26'),
(1363051, 'FIAT', '16', '4870.3881835938', 'de_dust2', '26'),
(1363050, 'Mixajlo!', '0', '87.341751098633', 'de_dust2', '26'),
(1363049, 'IP Address', '0', '99.413108825684', 'de_dust2', '26'),
(1363048, 'nikola257', '2', '658.31866455078', 'de_dust2', '26'),
(1363046, '(vaske)', '1', '263.9743347168', 'de_dust2', '26'),
(1363047, 'MM5', '3', '222.01992797852', 'de_dust2', '26'),
(1362920, 'azmi 109', '3', '757.86151123047', 'zm_gbox5', '12'),
(1362919, 'VaGner!', '0', '1337.5684814453', 'zm_gbox5', '12'),
(1362868, 'Ð¯ Ð½Ðµ Ð§Ð¸Ñ‚ÐµÑ€ Ð¯ Ð½Ðµ ÐŸÐ ', '8', '1805.1431884766', 'de_abaddon', '9'),
(1362867, 'Gorynich', '2', '1436.7458496094', 'de_abaddon', '9'),
(1362996, 'Instagram DD2 Only', '0', '45592.7578125', 'de_dust2_2x2', '4'),
(1362918, 'droxzuS<3', '1', '5324.0517578125', 'zm_gbox5', '12'),
(1362917, 'LastWorld', '4', '3845.2097167969', 'zm_gbox5', '12'),
(1362916, 'LeGeNDraY*', '1', '7886.71875', 'zm_gbox5', '12'),
(1362915, 'Ro.One', '5', '484.79919433594', 'zm_gbox5', '12'),
(1362914, 'Angelia Jolie', '0', '449099.09375', 'zm_gbox5', '12'),
(1362913, 'N1', '0', '1154.1430664062', 'zm_gbox5', '12'),
(1362912, 'ThunderZM', '0', '449099.09375', 'zm_gbox5', '12'),
(1362865, 'ParavoZZ', '0', '1805.5291748047', 'de_abaddon', '9'),
(1362866, 'Ignotis', '10', '711.50469970703', 'de_abaddon', '9'),
(1362863, 'Pog}I{eP', '6', '1805.8828125', 'de_abaddon', '9'),
(1362864, '[NAVI]-NIDRAGEn            O_o', '1', '755.13122558594', 'de_abaddon', '9'),
(1362862, 'KABAN(N.TAGIL)', '3', '265.69073486328', 'de_abaddon', '9'),
(1362861, 'CS ARENA- Ã§Å¤Ñ€áº®Ï‡ :Ñ', '12', '654.25891113281', 'de_abaddon', '9'),
(1362860, 'veter', '0', '1222.4197998047', 'de_abaddon', '9'),
(1362859, 'Lost', '7', '1807.4411621094', 'de_abaddon', '9'),
(1362858, 'A 001 ROM', '6', '3748.2856445312', 'de_abaddon', '9'),
(1362857, 'MaHrycT', '13', '4385.912109375', 'de_abaddon', '9'),
(1362856, 'AAAAAAAAAAAAAAAAAAAAAA', '3', '68.443534851074', 'de_abaddon', '9'),
(1362855, 'SHARIK', '0', '85.655647277832', 'de_abaddon', '9'),
(1362854, 'VDV', '4', '862.31268310547', 'de_abaddon', '9'),
(1362853, 'Basta', '2', '1160.0422363281', 'de_abaddon', '9'),
(1362852, 'Ð¼ÐµÐ½Ñ Ð½Ðµ ÑƒÐ±Ð¸Ñ‚ÑŒ', '0', '1800.6791992188', 'de_abaddon', '9'),
(1362851, 'Evgen_47_rus', '5', '439.45358276367', 'de_abaddon', '9'),
(1362850, 'Mike', '2', '87.596450805664', 'de_abaddon', '9'),
(1362849, 'dymagan', '2', '4167.87109375', 'de_abaddon', '9'),
(1362848, 'Timur', '5', '796.49591064453', 'de_abaddon', '9'),
(1363037, 'NZXT | eZio', '1', '235.39152526855', 'de_dust2_snow', '23');

-- --------------------------------------------------------

--
-- Table structure for table `poruke`
--

CREATE TABLE `poruke` (
  `id` int(11) NOT NULL,
  `za` varchar(100) NOT NULL,
  `od` varchar(100) NOT NULL,
  `title` text NOT NULL,
  `message` text NOT NULL,
  `time` varchar(100) NOT NULL,
  `nza` varchar(100) NOT NULL,
  `lastanswer` varchar(100) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prijave_s`
--

CREATE TABLE `prijave_s` (
  `id` int(11) NOT NULL,
  `sid` varchar(100) NOT NULL,
  `razlog` varchar(100) NOT NULL,
  `napomena` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `ip_adresa` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile_feed`
--

CREATE TABLE `profile_feed` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile_log`
--

CREATE TABLE `profile_log` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `var1` varchar(100) NOT NULL,
  `var2` varchar(100) NOT NULL,
  `var3` varchar(100) NOT NULL,
  `var4` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_log`
--

INSERT INTO `profile_log` (`id`, `userid`, `var1`, `var2`, `var3`, `var4`, `type`, `time`) VALUES
(1, '1', '1', 'Bogoljub', '2', '', '2', '1541326737'),
(2, '2', '2', 'Spodoba', '4', '', '2', '1541879063');

-- --------------------------------------------------------

--
-- Table structure for table `profile_visits`
--

CREATE TABLE `profile_visits` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `visitorid` varchar(100) NOT NULL,
  `visitorname` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_visits`
--

INSERT INTO `profile_visits` (`id`, `userid`, `username`, `visitorid`, `visitorname`, `time`) VALUES
(1, '1', 'Bogoljub', '2', 'Spodoba', '1541879361');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `id` int(11) NOT NULL,
  `ip` varchar(128) NOT NULL,
  `rank_pts` float(10,6) NOT NULL DEFAULT '0.000000',
  `rank` int(11) NOT NULL DEFAULT '0',
  `best_rank` varchar(10) NOT NULL,
  `worst_rank` varchar(10) NOT NULL,
  `game` varchar(128) NOT NULL,
  `gamemod` varchar(128) NOT NULL,
  `online` tinyint(4) NOT NULL DEFAULT '0',
  `hostname` varchar(128) NOT NULL DEFAULT 'n/a',
  `mapname` varchar(128) NOT NULL DEFAULT 'n/a',
  `playercount` varchar(1000) NOT NULL,
  `num_players` varchar(10) NOT NULL DEFAULT '0',
  `max_players` varchar(10) NOT NULL DEFAULT '0',
  `location` varchar(128) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `last_chart_update` int(11) NOT NULL DEFAULT '0',
  `chart_updates` varchar(64) NOT NULL DEFAULT '|00|00|00|00|00|00|00|00|00|00|00|00',
  `rank_chart_updates` varchar(60) NOT NULL DEFAULT '|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00',
  `added` varchar(30) NOT NULL,
  `addedid` varchar(30) NOT NULL,
  `forum` text NOT NULL,
  `owner` varchar(30) NOT NULL,
  `ownerid` varchar(30) NOT NULL,
  `playercount_week` varchar(1000) NOT NULL,
  `chart_week` varchar(64) NOT NULL DEFAULT '|Mon|Tue|Wed|Thu|Fri|Sat|Sun',
  `chart_month` varchar(100) NOT NULL DEFAULT '|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00',
  `rank_chart_count` varchar(5000) NOT NULL DEFAULT '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000',
  `playercount_6h` varchar(1000) NOT NULL,
  `playercount_month` varchar(5000) NOT NULL,
  `playercount_hour` varchar(1000) NOT NULL,
  `last_map` varchar(100) NOT NULL,
  `vip` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `ip`, `rank_pts`, `rank`, `best_rank`, `worst_rank`, `game`, `gamemod`, `online`, `hostname`, `mapname`, `playercount`, `num_players`, `max_players`, `location`, `last_update`, `last_chart_update`, `chart_updates`, `rank_chart_updates`, `added`, `addedid`, `forum`, `owner`, `ownerid`, `playercount_week`, `chart_week`, `chart_month`, `rank_chart_count`, `playercount_6h`, `playercount_month`, `playercount_hour`, `last_map`, `vip`) VALUES
(1, '136.243.213.253:27015', 32.932613, 18, '1', '18', 'cs16', 'FUN', 1, 'Instagram ClanWar', 'de_dust2', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '12', 'BA', 1546257619, 1546257620, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00012,00012,00012,00012,00012,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00018,00018,00018', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,00,00,00,00,01,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_dust2', '0'),
(2, '136.243.213.253:27016', 52.062500, 15, '2', '15', 'cs16', 'COD', 0, 'Impossible | COD:MW4[KS+VIP+50 LVL START]', 'de_inferno', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '32', 'BA', 1545583515, 1546257618, '|18|20|22|00|02|04|06|08|10|12|14|16', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00010,00010,00011,00011,00011,00011,00011,00011,00011,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00015,00015,00015', '00,00,00,00,00,00', '02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,00,01,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,01,00,00,01,01,01,01,01,01,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,01,01,01,01,01,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_nuke', '0'),
(3, '136.243.213.253:27017', 11.666667, 21, '3', '21', 'cs16', 'ZM', 0, 'New Counter Strike 1.6 Server by gb-hoster.me', 'de_dust2', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '24', 'RS', 1545567313, 1546257621, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00019,00019,00019,00019,00019,00019,00019,00019,00020,00020,00021', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,00,01,01,01,01,01,02,02,03,03,03,03,03,03,03,03,03,04,04,04,04,04,04,04,03,03,03,02,00,00,02,02,02,02,02,02,00,00,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_inferno', '0'),
(4, '136.243.213.253:27020', 213.448837, 9, '1', '9', 'cs16', 'PUB', 1, 'Instagram DD2 Onlyâ„¢ [FDL]', 'de_dust2_2x2', '04,04,04,05,06,07,07,08,09,10,10,10,10,10,09,08,07,06,06,05,04,03,02,02', '2', '', 'BA', 1546257614, 1546257616, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Facebook Grupa: https://www.facebook.com/groups/instagrampublic1/ &lt;&lt; pridruÅ¾i se...', 'Spodoba', '2', '05,05,07,09,10,12,12,12,13,13,13,12,11,11,09,07,05,05,05,04,03,03,03,03,03,04,04,04,05,00,05,05,05,07,07,07,07,06,06,06,05,05,05,05,04,03,02,02,02,02,03,03,03,03,04,05,07,09,10,09,09,09,09,09,09,09,08,07,04,02,02,02,02,03,05,06,07,08,08,09,10,11,11,11,11,10,09,07,06,06,05,04,04,03,02,02,03,04,00,05,06,06,08,10,12,00,12,12,12,11,09,09,08,08,06,04,03,02,02,02,03,03,04,04,05,05,06,06,07,07,08,07,07,07,06,05,05,05,04,04,03,03,03,03,04,04,04,05,06,07,07,08,09,10,10,10,10,10,09,08,07,06,06,05,04,03,02,02', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00007,00007,00007,00007,00007,00007,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009', '05,03,06,10,07,02', '06,06,06,06,06,06,06,06,06,06,06,06,05,05,05,04,04,04,05,05,05,05,05,05,05,05,05,04,04,04,05,05,05,06,06,06,05,05,05,05,05,05,06,06,06,07,07,07,06,06,06,06,06,06,07,07,07,09,09,09,07,07,07,08,08,08,10,10,10,11,11,11,09,09,09,09,09,11,11,11,11,10,10,10,08,08,08,06,06,06,08,08,08,08,08,08,06,06,06,06,06,08,08,08,08,09,09,09,08,08,08,07,07,07,08,08,08,08,08,08,00,00,06,05,05,05,06,06,06,07,07,07,06,06,06,07,07,07,09,09,09,11,11,11,10,10,10,09,09,09,12,12,12,12,12,12,10,10,10,10,10,00,00,00,00,00,08,08,05,05,05,05,05,05,08,08,08,08,08,08,08,08,08,10,10,10,13,13,13,14,14,14,12,12,12,11,11,11,14,14,14,14,14,14,12,12,12,11,11,11,13,13,13,13,13,13,10,10,10,09,09,09,11,11,11,12,12,12,09,09,09,08,08,08,10,10,10,10,10,10,08,08,08,08,08,08,11,11,11,13,13,13,11,11,12,12,12,12,13,13,13,12,12,12,08,08,08,07,07,07,07,07,07,06,06,06,05,05,05,04,04,04,05,05,05,06,06,06,05,05,05,06,06,07,07,07,07,08,08,08,06,00,06,06,06,06,07,07,07,08,08,08,06,06,06,06,06,06,07,07,07,07,07,07,05,05,05,05,05,05,06,06,06,07,07,07', '02,02,02,02,02,02,02,02,02,02,05,02', 'de_dust2_2x2', '0'),
(5, '136.243.213.253:27024', 4.766667, 22, '1', '22', 'cs16', 'JB', 0, 'Randomfucker\'s 2013', 'de_dust2', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '12', 'RS', 1545584435, 1546257622, '|19|21|23|01|03|05|07|09|11|13|15|17', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00018,00018,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00020,00020,00020,00020,00020,00020,00020,00020,00022,00022,00022,00022,00022,00022', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_dust2', '0'),
(24, '136.243.213.253:27028', 0.875000, 24, '21', '24', 'cs16', 'PUB', 0, 'Marvel Publicâ„¢', 'de_dust2', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '32', 'RS', 1545342315, 1546257622, '|23|01|03|05|07|09|11|13|15|17|19|21', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Mladenov1c', '13', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00022,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00022,00022,00022,00022,00022,00022,00022,00022,00022,00024,00024,00024,00024,00024,00024,00024,00024', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_train', '0'),
(17, '193.192.58.150:27021', 196.625000, 10, '7', '17', 'cs16', 'PUB', 0, 'Khan Community Â© | Public [Free-VIP]', 'de_inferno_2x2', '03,04,04,05,05,07,08,09,10,10,00,10,09,09,00,08,00,05,04,03,02,02,03,00', '8', '32', 'DE', 1546257615, 1546257616, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'AkiJ03', '5', 'Nema', '', '', '03,03,04,05,06,08,00,08,08,08,08,08,08,08,07,06,04,04,03,04,04,04,00,04,05,06,06,07,00,10,10,10,10,10,00,09,00,00,00,05,00,04,03,00,03,00,00,04,05,05,06,07,07,07,08,08,00,00,08,07,00,06,05,05,04,04,03,02,03,02,02,03,04,05,05,06,06,07,08,09,09,09,10,09,08,07,07,06,06,05,00,04,03,03,00,03,04,04,00,06,07,09,10,11,12,13,00,00,00,11,10,09,06,06,05,04,03,02,03,04,04,05,06,07,00,10,00,11,11,11,11,10,09,09,08,05,05,00,00,03,03,02,02,02,03,04,04,05,05,07,08,09,10,10,10,10,00,09,08,00,07,05,04,03,02,02,00,03', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00008,00008,00007,00008,00008,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010', '05,02,05,10,07,00', '09,09,09,07,07,07,10,10,00,10,00,10,08,08,08,10,10,10,09,09,09,09,09,09,06,06,06,00,04,04,03,00,00,00,02,02,02,02,02,02,00,02,02,02,02,03,03,03,03,03,03,00,03,03,00,02,02,00,03,00,04,00,00,04,04,04,06,00,00,06,06,06,00,07,07,00,08,09,09,09,09,00,07,07,06,06,06,07,00,00,06,06,05,05,05,05,04,00,00,05,05,06,06,06,06,05,05,05,05,05,05,06,06,00,06,06,06,05,05,05,04,04,04,05,05,05,00,06,06,05,00,05,00,04,04,00,05,05,06,00,06,05,05,05,04,00,00,03,03,00,00,04,00,00,04,04,03,03,03,00,00,00,05,00,00,05,05,05,04,04,04,05,05,05,06,06,00,05,05,05,04,04,04,04,04,04,00,05,05,04,04,04,03,03,03,03,03,03,03,03,03,03,03,00,03,03,03,04,04,00,00,05,05,00,04,04,04,04,04,00,06,06,05,05,00,04,04,04,03,03,03,04,00,04,04,04,00,00,00,03,03,03,00,00,04,00,04,04,04,00,03,03,02,02,00,03,03,03,04,04,04,00,04,04,05,05,00,06,06,06,00,07,07,00,06,00,05,05,05,05,05,00,00,04,04,02,00,02,01,01,01,00,00,03,00,03,03,03,00,03,03,03,00,04,04,00,06,00,00,05,05,05,04,04,04,06,06,00,00,00,07,07,07,07,05,05,00,00,00,06,07,00,07,07,07,00', '02,02,02,02,00,02,00,09,05,07,08,08', 'de_inferno_2x2', '0'),
(8, '136.243.213.253:27019', 36.781250, 17, '4', '17', 'cs16', 'PUB', 1, 'Kvisko Public [24/7+New 2k19]', 'de_dust2', '02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02', '2', '32', 'RS', 1546257618, 1546257619, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '01,01,01,01,02,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,01,01,01,02,02,02,02,02,02,03,03,03,03,03,03,03,03,03,04,03,03,03,02,02,02,02,02,02,02,02,02,02,02,02,03,03,02,02,02,02,02,02,03,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,01,01,02,01,02,02,03,02,03,03,03,03,03,03,03,03,03,02,02,02,02,02,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00016,00017,00017,00017', '03,02,02,02,02,02', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,02,02,02,02,03,03,03,04,04,04,04,04,04,05,05,05,05,05,05,03,03,03,03,03,03,03,03,03,03,03,03,03,03,03,02,02,02,03,03,03,03,03,03,00,00,02,02,02,02,02,02,02,02,02,02,02,02,02,01,01,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,00,00,00,00,00,01,01,00,00,00,01,01,01,01,01,01,01,01,01,01,01,01,01,01,01,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,03,03,03,03,03,03,03,03,03,03,03,03,03,03,03,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,03,03,03,03,03,03,03,03,03,03,03,03,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02', '02,02,00,02,02,02,02,00,02,02,02,02', 'de_dust2', '0'),
(6, '54.36.85.243:7778', 13.160000, 1, '6', '26', 'samp', 'DEFAULT', 0, 'Perfect Gaming | Otvoren | Free Vip 4', 'PGaming', '0002,0002,0002,0002,0002,0002,0002,0002,0002,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '0', '50', 'RS', 1546204515, 1546257620, '|23|01|03|05|07|09|11|13|15|17|19|21', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '0001,0000,0000,0006,0000,0000,0000,0000,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0001,0001,0001,0001,0001,0001,0001,0001,0001,0001,0001,0001,0000,0000,0002,0000,0000,0000,0000,0000,0000,0000,0000,0000,0002,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0002,0003,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0001,0000,0000,0000,0000,0000,0000,0000,0004,0002,0003,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0000,0000,0000,0000,0001,0001,0000,0000,0000,0002,0000,0005,0006,0002,0000,0000,0002,0002,0002,0002,0002,0002,0002,0002,0002,0002,0004,0003,0005,0000,0000,0000,0000,0002,0006,0002,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001', '0002,0002,0002,0000,0000,0000', '0003,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0003,0000,0000,0000,0000,0000,0000,0000,0001,0002,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0002,0000,0001,0000,0000,0000,0000,0000,0003,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0010,0003,0003,0003,0002,0003,0003,0004,0002,0003,0007,0001,0004,0000,0001,0001,0001,0001,0005,0004,0007,0006,0002,0002,0004,0001,0001,0001,0001,0001,0003,0003,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0001,0001,0001,0001,0001,0001,0000,0000,0000,0000,0000,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0002,0001,0000,0000,0000,0000,0000,0000,0001,0000,0000,0000,0004,0003,0001,0000,0000,0000,0000,0000,0000,0000,0001,0000,0002,0005,0002,0000,0002,0002,0002,0002,0002,0003,0000,0000,0002,0002,0000,0000,0000,0000,0000,0000,0000', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', 'PGaming', '0'),
(7, '54.36.85.243:7779', 0.000000, 3, '7', '28', 'samp', 'DEFAULT', 0, '[E:RPG] Elite Community [2019 + Winter]', 'Elite Community', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '0', '10', 'RS', 1543749314, 1546257623, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Spodoba', '2', 'Nema', '', '', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003', '0000,0000,0000,0000,0000,0000', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', 'Elite Community', '0'),
(9, '212.76.128.77:27015', 640.156250, 1, '1', '11', 'cs16', 'PUB', 1, 'CS ARENA-PODOLSKYI SERVER', 'de_abaddon', '23,25,26,28,30,29,30,30,30,30,30,29,28,27,25,24,23,23,22,22,22,22,22,23', '32', '32', 'RS', 1546257610, 1546257612, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Daki', '3', 'Nema', '', '', '24,26,27,28,29,29,29,30,30,29,29,29,28,28,28,28,29,29,29,29,29,29,30,30,30,31,32,32,32,31,31,31,31,30,29,29,28,27,25,25,24,24,24,24,25,25,25,25,25,27,28,28,29,27,27,27,27,27,28,26,25,24,23,22,21,23,23,23,23,22,22,24,26,26,28,29,30,29,28,28,28,28,29,28,27,25,24,22,21,22,22,22,22,22,23,23,24,26,26,28,29,29,29,29,29,29,28,27,27,25,24,24,24,24,24,23,23,23,24,24,25,27,28,29,29,28,28,27,28,28,28,26,25,24,22,19,19,21,21,21,21,21,21,22,23,25,26,28,00,29,30,30,30,30,30,29,28,27,25,24,23,23,22,22,22,22,22,23', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001', '19,21,00,30,23,22', '24,24,24,24,24,24,24,24,24,23,23,23,23,23,23,25,25,25,26,26,26,26,26,26,25,25,25,26,26,26,27,27,27,26,26,26,24,24,00,20,20,20,21,21,21,19,19,19,17,17,17,18,18,18,19,19,19,22,22,22,21,21,21,22,22,22,23,23,23,22,22,22,21,21,21,23,23,25,25,25,25,25,25,25,26,26,26,27,27,27,29,29,28,28,28,28,27,27,27,27,27,27,27,27,27,25,25,25,23,23,00,23,23,23,24,24,24,23,23,23,22,22,24,24,24,24,26,26,26,25,00,25,24,24,24,24,24,24,25,25,25,24,24,24,23,23,23,24,24,24,26,26,26,26,26,26,26,26,26,28,28,28,28,28,28,27,27,27,25,25,25,25,25,25,25,25,23,23,23,22,22,22,22,24,24,24,26,26,26,25,25,25,24,24,24,25,25,25,26,26,26,24,24,24,23,23,23,24,24,24,25,25,25,24,24,24,23,23,23,25,25,25,26,26,26,24,24,24,23,23,23,25,25,25,26,26,26,25,25,25,24,24,21,21,21,21,22,22,22,21,21,21,19,19,20,20,20,20,21,21,21,26,26,26,27,27,27,28,28,28,30,30,30,29,29,29,28,28,28,28,28,28,28,28,28,26,26,26,25,25,25,26,26,27,27,27,27,26,26,26,25,25,25,26,26,26,27,27,27,26,26,26,25,25,25,26,26,26,27,27,27,25,25,25,24,24,20,20,20,20,21,21,21,20,20,20', '14,15,11,21,20,20,32,31,30,30,32,32', 'de_aztec', '0'),
(10, '213.238.173.53:27015', 500.343750, 4, '2', '8', 'cs16', 'ZM', 1, 'World War\'Z | Zombie Escape | WWARCS [TR]', 'ze_highmountain_wwarz_v1', '14,16,18,19,21,23,24,26,25,25,23,22,20,18,16,15,13,11,10,08,07,07,07,08', '23', '32', 'RS', 1546257612, 1546257613, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Daki', '3', 'Nema', '', '', '11,12,14,16,18,22,22,23,24,24,23,22,19,19,18,15,11,11,09,08,07,07,07,08,10,13,13,15,17,20,20,22,23,25,25,24,22,21,19,17,00,13,11,10,09,08,08,09,10,12,14,15,17,20,21,23,24,24,24,23,21,20,18,16,14,12,11,10,09,08,09,10,11,12,14,16,18,20,22,23,24,25,24,23,23,21,19,17,15,13,11,10,09,08,09,09,11,13,15,16,18,21,23,25,26,27,27,26,24,22,00,18,14,14,12,11,11,10,10,12,13,15,17,19,21,23,24,24,25,25,25,23,00,21,19,15,15,12,11,10,10,11,11,13,14,16,18,19,21,23,24,26,25,25,23,22,20,18,16,15,13,11,10,08,07,07,07,08', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004,00004', '15,11,21,23,13,00', '07,07,07,07,07,07,11,11,11,11,11,11,12,12,12,15,15,15,17,17,17,17,17,17,15,15,00,12,12,12,15,15,15,14,14,14,11,11,11,11,11,11,14,14,14,14,14,14,12,12,12,13,13,13,15,15,15,15,15,15,13,13,13,16,16,16,19,19,00,18,18,18,16,16,16,17,17,19,19,19,19,16,16,16,13,13,13,13,13,13,14,14,14,14,14,14,12,12,12,14,14,00,16,16,16,16,16,16,14,14,14,15,15,15,17,17,17,17,17,17,15,15,15,15,15,15,17,17,17,16,16,16,14,14,14,14,14,14,17,17,17,17,17,17,15,15,15,16,16,16,19,19,19,18,18,18,15,15,15,16,16,16,18,18,18,17,17,17,15,15,15,13,13,13,15,15,14,14,14,14,11,11,11,12,12,12,14,14,14,17,17,17,14,14,14,14,14,14,17,17,17,16,16,16,14,14,14,14,14,14,17,17,17,17,17,17,14,14,14,15,15,15,18,18,18,17,17,17,16,16,00,17,17,17,20,20,00,20,20,20,17,17,18,18,18,18,00,20,20,19,19,19,16,16,16,16,16,16,18,18,18,17,17,17,14,14,00,14,14,14,17,17,17,16,16,16,13,13,13,14,14,14,16,16,16,16,16,16,13,13,13,13,13,17,17,17,17,17,17,17,15,15,15,16,16,16,19,19,19,18,18,18,16,16,16,00,17,17,19,19,19,19,19,19,16,16,17,17,17,17,19,19,19,18,18,18', '03,03,03,03,04,08,07,12,16,14,18,23', 'ze_jurassicpark_a1', '0'),
(11, '213.238.173.43:27015', 240.406250, 8, '5', '10', 'cs16', 'JB', 1, 'MRWarrIors JailbreaK Ailesi | Ts60 - CS43 | BAÅžLIYORUZ!!', 'jail_buyukisyan_dark', '00,07,08,08,09,10,10,11,10,10,00,09,07,08,07,06,06,05,04,03,03,03,03,03', '3', '32', 'RS', 1546257614, 1546257615, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Daki', '3', 'Nema', '', '', '03,04,05,06,06,07,07,08,08,09,09,09,08,08,07,07,05,05,05,04,04,03,03,04,04,05,05,06,07,09,09,10,11,11,11,11,12,11,10,09,00,07,06,06,05,04,04,05,05,06,07,08,08,09,10,10,11,11,11,11,11,10,09,08,07,07,06,05,05,04,04,05,05,06,06,07,07,08,09,10,10,10,10,10,09,09,08,07,06,06,05,04,03,03,03,03,04,05,06,07,08,09,10,10,10,10,10,10,10,09,08,07,05,05,04,04,05,04,04,05,05,06,06,07,08,08,09,09,09,09,09,09,08,07,07,06,06,05,00,04,04,04,05,06,00,07,08,08,09,10,10,11,10,10,09,09,07,08,07,06,06,05,04,03,03,03,03,03', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008', '06,05,09,00,06,03', '09,09,09,09,09,09,10,10,00,09,09,09,07,07,07,09,09,09,11,11,11,10,10,10,09,09,09,08,08,08,09,09,09,09,09,09,07,00,07,00,08,08,09,09,09,09,09,09,07,07,07,08,08,08,09,09,09,08,08,00,07,07,07,08,08,08,11,11,00,11,11,11,10,10,10,11,11,12,12,12,12,10,10,10,07,07,07,06,06,06,07,07,06,06,06,06,05,05,05,04,04,05,05,05,00,05,05,05,04,04,04,04,04,04,05,05,05,05,05,05,05,05,05,05,05,05,05,05,05,05,05,05,04,04,04,04,04,04,05,05,05,05,05,05,05,05,05,06,06,06,07,07,07,07,07,07,06,06,06,05,05,05,06,06,00,06,06,06,05,05,05,04,04,04,05,05,05,05,05,05,04,04,04,04,04,04,05,05,00,05,05,05,04,04,04,04,04,04,05,05,00,05,05,05,04,04,04,05,05,05,05,05,05,05,05,05,04,04,04,04,04,00,05,05,05,05,05,05,05,05,05,06,06,06,07,07,07,07,07,07,07,07,07,07,07,07,09,00,00,09,09,09,08,08,08,08,08,08,09,09,09,07,07,07,06,06,06,04,04,04,06,06,06,06,06,00,05,05,05,04,04,04,06,06,06,07,07,07,06,06,06,06,06,07,07,07,07,08,08,08,06,06,06,06,06,06,06,06,06,05,05,05,04,04,04,05,05,05,06,06,06,05,05,05,00,06,07,07,07,07,06,06,06,06,06,06', '03,03,03,03,03,03,03,03,03,03,04,03', 'jail_buyukisyan_dark', '0'),
(12, '178.32.241.13:27015', 574.906250, 3, '2', '8', 'cs16', 'ZM', 1, 'ThunderZM.CsBlackDevil.Com [Zombie Plague 6.2]', 'zm_gbox5', '16,16,17,18,19,21,23,25,26,28,28,28,27,27,25,24,23,21,19,17,15,14,13,13', '23', '32', 'RS', 1546257611, 1546257613, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Daki', '3', 'Nema', '', '', '16,17,18,20,22,26,26,26,27,27,27,28,27,27,25,24,21,21,19,18,17,16,15,15,16,17,17,19,21,24,24,25,26,26,26,25,25,24,23,21,19,16,16,14,12,11,12,13,13,13,15,17,18,20,22,24,25,26,25,25,25,23,21,19,17,16,14,13,12,12,14,14,15,17,19,21,22,24,25,00,25,25,24,23,23,21,20,18,17,14,12,10,12,11,12,12,12,14,15,17,19,21,23,25,26,27,27,26,26,25,23,22,19,19,17,16,15,14,14,16,16,17,19,20,21,23,25,26,27,28,29,28,00,27,26,24,24,22,20,18,17,15,15,15,16,16,17,18,19,21,23,25,26,28,28,28,27,27,25,24,23,21,19,17,15,14,13,13', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003,00003', '24,15,19,28,23,13', '12,12,12,12,12,12,15,15,15,17,17,17,00,16,16,13,13,00,16,16,16,17,17,17,16,16,16,15,15,15,17,17,17,20,20,20,18,18,18,17,17,17,19,19,19,20,20,20,18,18,18,18,18,18,20,20,20,20,20,20,19,19,19,19,19,19,20,20,20,21,21,21,19,19,19,19,19,21,21,21,21,22,22,22,20,20,20,20,20,20,22,22,23,23,23,23,20,20,20,16,16,17,17,17,17,16,16,16,14,14,14,14,14,14,16,16,16,20,20,20,19,19,19,19,19,19,21,21,21,00,22,22,18,18,18,16,16,16,17,17,17,17,17,00,15,15,15,15,15,15,20,20,20,21,21,21,21,21,21,21,21,21,24,00,24,24,24,24,22,22,22,21,21,21,23,23,23,23,23,23,21,21,21,21,21,21,24,24,24,24,24,24,22,22,22,22,22,22,23,23,23,23,23,23,21,21,21,22,22,22,24,24,24,00,24,24,22,22,22,00,21,21,22,22,22,18,18,18,17,17,17,17,17,17,19,19,19,18,18,18,17,17,21,21,21,21,18,18,18,17,17,17,16,16,16,16,16,16,18,18,18,18,18,18,20,20,20,20,20,20,22,22,22,22,22,22,19,19,19,19,19,19,20,20,20,19,19,19,17,17,17,18,18,20,20,20,20,20,20,20,18,18,18,18,18,18,20,20,20,20,20,20,18,18,18,19,19,19,22,22,22,22,22,22,20,20,20,20,20,20,23,23,23,23,23,23', '17,13,11,10,09,09,10,12,10,19,19,23', 'zm_dust_attack4', '0'),
(13, '77.220.180.73:27015', 583.281250, 2, '1', '9', 'cs16', 'PUB', 0, 'Extra Classic [Russia]', 'de_rust', '14,16,17,16,18,18,20,18,21,21,00,00,20,19,17,17,00,19,00,19,18,15,15,00', '32', '32', 'RS', 1546257611, 1546257612, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Daki', '3', 'Nema', '', '', '20,20,23,26,00,28,00,26,23,21,00,00,23,00,22,22,21,21,18,18,21,23,00,21,19,17,17,17,18,18,18,00,21,24,24,23,23,24,00,00,19,20,20,20,00,00,18,19,19,20,21,00,22,20,21,19,16,00,16,15,00,12,11,11,10,13,13,00,17,17,17,00,19,20,00,00,25,25,25,26,00,25,23,25,25,24,00,00,00,20,00,19,00,19,22,22,00,20,00,18,00,22,23,00,00,26,00,00,21,23,22,00,00,21,21,18,18,15,18,21,19,19,20,23,22,23,00,23,23,26,00,00,27,25,24,21,00,18,00,18,15,15,00,13,00,00,00,16,18,18,20,00,21,21,21,21,20,19,17,17,16,19,19,19,18,15,00,18', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00001,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002', '21,15,18,21,00,00', '03,03,00,05,05,05,05,05,05,05,05,05,00,09,09,13,00,13,00,00,00,15,15,15,00,18,00,00,18,18,15,15,15,14,00,14,12,12,12,09,00,00,09,09,09,09,09,09,09,09,00,08,08,08,00,06,06,08,00,08,06,00,06,06,06,06,06,00,00,08,08,00,12,00,12,09,00,00,11,00,11,14,14,14,14,14,00,13,00,13,10,10,13,00,13,13,13,13,13,00,00,16,00,00,16,16,00,00,18,18,18,17,17,00,18,18,18,18,18,18,00,17,17,17,17,00,00,18,18,19,00,19,18,18,18,19,19,19,20,00,00,21,21,00,18,00,18,14,14,14,15,15,00,15,00,15,00,14,14,00,00,09,13,13,00,15,00,15,14,14,14,00,10,00,10,00,10,10,00,10,07,07,07,09,09,09,11,00,11,11,00,11,11,11,00,15,15,15,20,20,00,16,16,16,15,15,00,15,15,00,15,15,15,00,10,10,08,00,08,08,08,00,06,06,06,09,09,09,06,06,06,09,00,09,00,00,00,00,11,00,14,14,00,14,00,00,18,00,00,18,00,18,00,17,22,22,00,22,22,22,22,00,19,19,00,19,00,15,15,00,00,16,00,11,11,00,08,08,00,11,11,00,08,08,08,08,08,00,04,04,04,00,00,12,12,12,12,08,00,08,08,08,00,08,08,08,08,00,00,04,04,00,00,03,03,07,00,07,11,00,00,15,15,00,17,17,20,20,00,20,21,00,21,17,00,00', '19,17,00,20,32,29,00,24,00,32,32,32', 'de_nuke', '0'),
(14, '136.243.213.252:27015', 0.093750, 25, '13', '25', 'cs16', 'PUB', 0, '[TW] Nova-Garda |**VIP**|', 'de_isolation', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '32', 'RS', 1543100417, 1546257623, '|01|03|05|07|09|11|13|15|17|19|21|23', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'TWcs', '4', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00019,00020,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00021,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00022,00023,00023,00023,00023,00023,00023,00023,00023,00025,00025,00025,00025,00025,00025,00025,00025,00025', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_nuke', '0'),
(15, '136.243.213.252:27017', 1.843750, 23, '12', '23', 'cs16', 'PUB', 0, '[TW] Knife Arena | [VIP] + [FDL]', 'de_nuke', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '0', '32', 'RS', 1543100417, 1546257622, '|01|03|05|07|09|11|13|15|17|19|21|23', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'TWcs', '4', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00020,00021,00021,00021,00021,00021,00021,00021,00023,00023,00023,00023,00023,00023,00023,00023', '00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,00,00,00,00,00', 'de_inferno', '0');
INSERT INTO `servers` (`id`, `ip`, `rank_pts`, `rank`, `best_rank`, `worst_rank`, `game`, `gamemod`, `online`, `hostname`, `mapname`, `playercount`, `num_players`, `max_players`, `location`, `last_update`, `last_chart_update`, `chart_updates`, `rank_chart_updates`, `added`, `addedid`, `forum`, `owner`, `ownerid`, `playercount_week`, `chart_week`, `chart_month`, `rank_chart_count`, `playercount_6h`, `playercount_month`, `playercount_hour`, `last_map`, `vip`) VALUES
(16, '87.98.241.203:27570', 267.937500, 7, '7', '11', 'cs16', 'COD', 1, 'KISS MY ASS COD:MW4 [VIP+FDL+BYM+50 START LVL+/GET]', 'de_dust2_2018', '13,16,18,17,19,21,22,24,25,25,25,24,23,21,19,19,17,15,13,11,10,09,09,10', '28', '32', 'RS', 1546257614, 1546257615, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Bogoljub', '1', 'Nema', '', '', '00,07,09,12,13,16,16,18,19,19,22,22,19,19,17,15,13,13,11,10,08,09,08,08,09,11,11,13,15,19,19,20,22,22,22,22,20,19,18,17,15,12,11,09,08,08,08,09,10,12,14,16,17,19,22,23,25,25,25,25,25,24,22,20,19,16,00,12,11,00,09,09,09,11,12,14,15,17,19,22,23,25,27,27,00,23,22,20,18,17,14,12,11,10,10,10,11,14,16,18,20,22,25,26,27,28,28,28,25,24,22,20,16,16,13,12,10,09,09,10,12,12,13,16,18,20,22,24,25,25,26,25,00,24,22,18,18,16,15,13,12,12,12,13,13,16,18,17,00,21,22,24,25,25,25,24,23,21,19,19,17,15,13,11,10,09,09,10', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00009,00008,00008,00008,00008,00008,00008,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007', '18,12,19,25,17,09', '14,14,14,15,15,15,18,18,18,00,15,15,12,12,12,10,00,00,00,11,11,08,08,00,05,00,00,05,00,05,06,06,06,09,09,09,00,08,00,00,08,08,09,00,00,11,11,11,10,10,10,10,10,00,00,00,00,09,09,09,06,06,00,07,00,07,08,00,00,08,08,00,00,09,00,11,00,11,00,00,11,00,09,00,00,06,06,06,00,00,00,00,02,00,02,02,03,00,00,06,06,00,08,08,08,09,09,00,10,10,00,13,13,00,00,12,00,11,00,11,00,09,09,09,00,09,10,10,10,00,08,08,00,00,09,00,09,09,11,11,11,00,11,00,09,00,09,09,09,00,00,08,08,00,08,08,05,00,05,00,03,00,00,00,00,07,00,00,08,08,00,08,00,00,09,09,11,11,11,11,07,07,07,09,09,09,00,12,00,10,10,00,00,09,00,09,09,00,12,00,00,10,00,10,07,07,07,10,10,00,00,00,00,00,11,11,09,09,09,00,00,00,13,13,00,10,00,10,06,06,00,06,06,06,00,00,00,00,04,04,00,04,07,07,07,07,00,00,00,00,07,07,07,07,07,07,00,07,09,09,09,09,09,09,10,10,10,00,12,12,16,16,16,16,16,16,14,14,14,14,14,14,17,17,17,15,15,15,12,12,12,12,12,00,00,16,16,16,16,00,13,13,13,00,17,17,20,20,20,20,20,20,00,17,17,17,17,17,00,20,20,19,19,19,17,17,17,17,17,17,20,20,20,20,20,20', '09,02,04,02,03,05,06,12,19,19,31,28', 'de_dust2_2018', '0'),
(22, '178.32.137.193:27500', 98.687500, 12, '12', '20', 'cs16', 'BB', 1, '[SpK] ProHunteR Zombie BaseBuildeR [FREE VIP 24H]', 'bb_cg_ff_hunt_v8', '09,11,13,00,16,15,17,00,17,18,00,00,12,10,00,07,00,05,04,02,03,02,00,06', '27', '', 'RS', 1546257616, 1546257617, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'knele55', '9', 'Nema', '', '', '04,05,06,08,09,11,11,00,14,00,14,13,00,11,10,08,06,00,00,04,03,00,00,00,05,06,06,06,00,08,08,00,09,07,00,06,00,00,00,00,00,03,00,01,02,02,00,02,02,00,00,04,00,00,04,00,00,07,00,07,00,07,07,00,06,00,05,04,02,01,01,02,03,04,00,06,09,00,00,00,10,10,09,09,08,07,00,00,03,01,00,02,02,00,03,00,00,00,06,06,07,07,08,08,10,00,00,00,08,08,00,00,05,05,03,00,03,03,02,04,03,04,04,06,07,07,00,08,09,10,12,00,11,10,11,08,00,08,08,07,06,06,00,07,09,11,13,00,16,15,17,18,17,18,16,00,12,10,00,07,00,00,04,02,00,02,00,06', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00020,00019,00018,00016,00016,00016,00016,00016,00016,00016,00016,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00014,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012', '00,00,16,16,05,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,02,02,02,04,04,07,07,07,07,08,08,08,08,08,08,09,09,09,11,11,11,11,11,11,08,08,08,08,08,11,11,11,11,12,12,12,10,10,10,11,11,11,13,13,13,13,13,13,10,10,10,10,10,10,12,12,00,10,10,10,07,07,07,07,07,07,09,09,09,09,09,09,07,07,07,10,10,10,13,13,13,13,13,13,11,11,11,12,12,12,13,13,13,12,12,12,09,09,09,09,09,09,11,11,11,11,11,11,08,08,08,08,08,08,10,10,10,10,10,10,08,08,08,08,08,08,10,10,10,11,11,11,09,09,09,09,09,09,11,11,11,10,10,10,08,08,08,07,07,07,08,08,08,08,08,08,07,07,07,07,07,07,09,09,09,09,09,09,08,08,09,09,09,09,11,11,11,11,11,11,09,09,09,09,09,09,11,11,11,10,10,10,08,08,00,07,07,07,00,08,08,06,06,06,04,04,04,04,04,04,00,05,05,04,00,04,03,03,03,00,00,06,06,06,06,00,06,06,00,00,05,05,05,00,05,00,05,05,05,05,03,03,00,00,04,04,04,04,04,00,02,00,02,02,00,04,04,00,07,00,07,06,06,00', '02,02,02,02,00,00,01,10,10,16,28,27', 'bb_avatar_final', '0'),
(18, '193.192.58.150:27022', 132.582977, 11, '10', '15', 'cs16', 'CW', 1, 'Khan Community Â© | Clan War', 'de_dust2', '01,02,02,02,02,02,02,02,02,03,02,02,02,02,00,02,00,02,02,02,02,01,02,02', '2', '12', 'DE', 1546257615, 1546257616, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'AkiJ03', '5', 'Nema', '', '', '01,01,02,02,02,02,02,02,02,02,02,02,02,02,00,02,02,02,02,02,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,00,01,01,01,02,02,02,00,02,02,00,02,02,02,02,02,02,02,02,02,00,00,02,02,02,02,00,02,02,02,00,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,00,00,00,02,02,02,00,00,00,02,00,02,02,02,03,03,03,03,03,03,00,00,03,03,02,00,02,02,02,02,01,01,02,02,02,01,02,02,02,02,02,02,02,02,02,02,02,02,01,01,01,00,02,02,02,00,01,01,01,02,02,02,02,02,02,02,02,03,00,02,00,02,02,02,00,02,02,02,02,01,02,02', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00013,00013,00013,00013,00013,00012,00012,00012,00012,00011,00011,00011,00011,00011,00011,00011,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011,00011', '01,01,02,02,02,00', '01,01,01,01,01,01,01,01,01,01,01,01,02,02,02,02,02,02,02,02,00,02,02,02,02,00,02,00,02,02,01,01,00,00,01,01,02,02,02,01,01,01,01,00,01,01,01,01,01,01,01,01,01,01,00,01,01,01,01,00,02,02,00,02,00,02,00,02,00,03,03,03,02,02,02,02,02,02,02,00,00,00,02,02,01,01,00,01,01,00,00,01,02,02,02,02,02,00,00,02,02,02,00,02,02,02,02,00,02,02,02,02,00,00,02,02,02,02,02,02,01,01,01,01,01,01,02,02,02,01,00,01,01,01,01,02,02,02,02,00,02,02,02,02,02,02,00,02,02,02,00,01,01,01,01,01,01,01,01,00,00,01,01,01,01,01,00,01,01,01,00,00,00,01,02,02,02,02,02,00,02,02,02,02,02,02,02,02,02,02,00,02,02,02,02,02,00,02,02,00,02,00,01,01,01,01,00,00,02,02,02,00,02,02,02,02,02,02,02,00,00,02,00,02,00,02,02,00,01,01,01,01,01,00,01,00,00,01,01,00,01,01,00,01,01,01,00,01,01,00,00,00,00,01,01,00,00,01,01,01,01,00,01,00,00,00,00,01,01,01,01,00,01,01,01,01,01,01,01,01,01,00,01,01,01,01,00,00,01,00,01,01,01,01,01,01,01,02,00,02,00,02,00,02,02,02,02,00,00,02,02,02,02,02,02,02,00,00,02,02,00,02,02,00,01,01,02,00,00,02,02,00,02,02,02,00', '02,00,02,02,02,02,00,02,02,02,02,02', 'de_dust2', '0'),
(19, '193.192.58.126:27016', 64.500046, 13, '10', '16', 'cs16', 'OSTALO', 0, 'Khan Community Â© | Death Match [Small Maps]', 'aim_crazyjump', '00,01,00,01,01,01,01,01,01,01,00,00,01,00,00,00,00,00,00,00,01,01,01,00', '0', '12', 'DE', 1546257616, 1546257617, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'AkiJ03', '5', 'Nema', '', '', '00,00,00,00,00,00,00,00,01,01,01,01,01,01,00,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,00,01,01,00,00,01,00,01,01,00,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,00,00,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,01,00,01,00,01,00,00,00,00,00,00,00,00,00,01,01,01,01,01,01,00,00,01,01,01,00,00,00,00,00,00,00,00,01,01,01,00', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00011,00011,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00011,00011,00011,00011,00011,00011,00011,00011,00011,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00012,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013,00013', '00,00,01,00,00,00', '01,01,01,01,01,01,01,01,01,01,00,01,01,01,01,01,01,01,01,01,01,01,01,01,01,00,01,00,01,01,01,01,01,00,00,00,00,00,00,00,00,00,01,00,01,01,01,00,01,01,00,01,01,01,01,00,01,02,00,02,01,01,01,01,01,01,00,02,00,00,01,01,01,01,01,01,01,01,01,00,00,01,01,01,00,00,00,00,00,00,00,00,01,01,01,01,01,01,00,01,01,00,01,01,01,01,01,01,01,01,01,01,01,01,01,01,01,01,00,01,01,01,01,01,00,01,01,00,01,01,00,01,01,01,01,01,01,01,01,01,00,00,01,01,01,01,00,01,01,01,01,01,00,00,00,00,00,00,00,00,00,00,01,00,00,00,00,00,00,00,00,00,00,00,00,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,00,01,01,01,01,00,00,00,00,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,00,00,00,00,00,00,00,00,00,01,01,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00', '00,00,00,00,00,00,00,05,00,00,00,00', 'fy_baddust', '0'),
(20, '193.192.58.150:27020', 295.083313, 6, '5', '14', 'cs16', 'OSTALO', 0, 'Khan Community Â© | Afk', 'afk_6killer', '03,04,05,06,06,06,07,07,07,07,06,07,06,06,00,04,04,04,03,03,02,03,03,00', '5', '12', 'DE', 1546257613, 1546257614, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'AkiJ03', '5', 'Nema', '', '', '00,04,05,05,06,06,00,06,05,05,00,04,03,03,00,02,02,02,02,02,00,02,03,03,04,05,05,05,00,06,06,07,07,06,06,06,05,00,00,04,00,03,03,00,00,00,02,03,03,04,03,03,04,04,03,04,04,04,04,03,03,02,00,02,02,02,03,00,03,02,03,03,03,03,04,04,05,00,05,00,00,06,05,05,05,05,05,04,00,03,00,03,03,03,04,04,04,04,04,04,05,06,06,06,06,06,00,00,04,04,04,04,00,02,02,02,02,02,03,04,04,04,05,05,06,07,06,00,06,06,06,06,05,05,04,03,00,00,00,03,03,03,03,03,03,04,05,06,06,06,07,00,00,07,06,07,00,06,05,04,00,04,03,03,02,03,03,03', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00007,00007,00008,00007,00007,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00008,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00007,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006,00006', '03,03,06,00,04,00', '01,01,01,01,01,01,02,02,00,02,00,02,03,03,03,03,03,03,03,03,00,03,03,03,00,03,00,00,03,03,03,00,03,00,03,03,04,04,04,03,00,03,03,03,03,02,02,00,00,02,02,00,03,03,02,00,02,00,03,03,02,00,00,03,03,03,03,03,00,03,03,03,00,00,04,00,03,04,04,04,00,04,04,04,03,03,03,04,04,00,00,00,03,03,03,03,02,02,00,02,02,03,03,00,03,02,02,02,03,03,03,04,00,04,00,03,03,03,03,03,02,02,02,03,03,03,00,04,04,03,03,03,03,03,00,03,03,03,05,05,05,04,04,04,02,00,00,03,03,00,00,03,03,00,02,02,02,02,02,02,00,02,03,03,00,02,00,02,02,02,02,02,02,02,02,02,03,03,00,03,00,02,02,02,02,02,02,00,02,02,00,02,02,02,02,03,03,03,03,03,00,04,04,04,03,03,00,00,04,00,00,05,00,00,04,04,04,04,04,00,03,00,04,04,04,03,03,00,03,03,03,02,02,00,02,02,02,00,02,02,01,01,02,00,02,02,01,00,01,00,01,01,02,02,03,03,03,03,04,04,04,03,03,03,03,03,00,04,04,04,00,04,04,00,03,03,03,03,03,00,02,00,03,03,03,02,02,00,02,02,02,00,02,03,00,03,03,03,00,03,00,00,02,02,02,02,02,00,00,01,01,00,01,01,01,02,00,02,00,00,00,03,03,00,04,04,05,05,05,05,04,00,04,04,04,00', '02,02,02,02,00,03,02,04,07,08,07,05', 'afk_6killer', '0'),
(21, '193.104.68.45:27020', 400.281250, 5, '5', '16', 'cs16', 'PUB', 1, 'Fatality Family | Public', 'de_dust2', '20,17,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,01', '28', '32', 'RS', 1546257612, 1546257614, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'SteleTele', '8', 'Nema', '', '', '00,24,24,27,28,28,00,00,29,29,29,32,32,00,00,31,31,00,31,30,30,27,00,27,27,25,00,25,00,22,22,00,24,24,24,24,24,00,26,26,24,24,22,00,20,22,22,19,19,19,19,20,19,19,18,20,18,00,13,13,13,13,13,11,12,12,00,10,10,10,13,16,15,00,00,17,19,00,23,23,25,28,28,28,28,25,00,00,23,00,00,00,00,20,00,00,20,22,00,22,22,25,28,28,28,28,28,00,29,29,29,31,29,29,27,24,23,23,23,23,23,23,20,21,00,17,19,22,00,20,00,20,18,18,00,19,00,00,00,18,19,20,20,17,20,17,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,01', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00016,00015,00015,00014,00014,00014,00014,00013,00012,00012,00012,00012,00011,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00010,00009,00009,00009,00008,00008,00008,00008,00008,00008,00007,00007,00007,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005,00005', '00,20,00,00,00,01', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,02,00,02,00,02,04,00,04,08,08,08,08,00,00,00,11,11,12,12,12,12,12,12,09,00,09,10,10,10,10,10,10,09,09,09,00,06,00,10,10,00,12,00,12,12,00,12,16,00,16,17,17,17,21,00,21,21,21,23,23,23,23,00,22,00,20,20,20,16,16,00,00,12,09,00,09,09,06,06,00,00,00,00,08,00,00,12,12,12,12,12,12,16,16,00,00,14,14,00,00,16,13,00,13,13,13,13,00,13,13,08,08,00,08,08,08,08,00,08,12,12,00,08,08,00,08,00,08,12,12,00,00,12,00,12,12,12,08,08,08,08,08,08,00,10,00,09,09,09,09,09,00,10,10,10,00,10,14,00,00,14,00,14,14,14,14,14,18,18,18,14,00,14,17,00,17,17,17,17,17,00,17,00,14,00,13,13,00,17,00,17,18,00,18,15,15,15,15,00,15,00,00,00,12,12,00,11,11,11,06,06,06,10,10,10,00,07,07,00,07,07,07,00,00,00,08,08,12,00,00,12,00,12,16,16,00,20,20,00,00,25,25,27,27,27,00,23,23,19,19,00,19,00,19,14,14,14,09,09,09,04,04,00,00,06,06,08,00,08,04,04,04,00,07,07,00,07,00,00,11,11,00,12,00,10,10,10,10,10,00,07,07,07,11,11,11,10,00,00,10,00,00,10,10,00,14,00,00,00,00,00,00,00,00,07,07,07', '00,00,00,00,00,00,00,15,00,00,00,28', 'de_inferno', '0'),
(23, '136.243.213.253:27023', 56.937500, 14, '14', '21', 'cs16', 'JB', 1, 'BalkanForce Public', 'de_dust2_snow', '03,04,04,05,06,06,08,10,12,13,14,14,14,14,13,12,12,12,10,08,06,06,05,05', '10', '', 'RS', 1546257617, 1546257618, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Leafs', '10', 'Nema', 'Leafs', '10', '03,03,00,04,05,08,08,10,00,11,12,12,12,12,11,11,09,09,08,05,05,04,03,03,04,05,06,07,00,08,08,09,10,11,11,12,10,09,08,08,06,06,06,05,04,03,03,02,02,02,03,03,03,04,05,08,09,10,10,10,10,10,10,09,09,09,07,05,04,03,02,02,03,04,06,08,08,09,11,13,13,14,15,14,14,12,11,09,08,08,06,04,04,02,04,04,05,06,07,08,09,09,10,11,12,12,11,10,09,08,07,06,05,05,04,04,03,02,02,02,02,03,04,04,05,07,09,11,11,13,13,13,14,13,13,11,11,09,07,06,05,03,03,03,03,04,04,05,06,06,08,10,12,13,14,14,14,14,13,12,12,12,10,08,06,06,05,05', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00021,00019,00019,00019,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00018,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00017,00016,00016,00016,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00015,00014,00014,00014', '11,03,06,14,12,05', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,03,03,03,03,04,04,04,04,04,04,05,05,05,06,06,06,06,06,06,05,05,05,04,04,05,05,05,05,05,05,05,04,04,04,03,03,03,04,04,04,04,04,04,00,00,03,03,03,03,03,03,03,03,03,03,02,02,02,02,02,02,02,02,02,02,02,02,02,02,02,03,03,03,03,03,03,04,04,04,04,04,04,03,03,00,00,00,00,00,00,00,00,02,02,01,01,01,01,01,01,01,01,01,01,01,01,02,02,02,02,02,02,03,03,03,03,03,03,03,03,03,03,03,03,03,03,03,02,02,02,02,02,02,03,03,03,03,03,03,04,04,04,05,05,05,08,08,08,10,10,10,09,09,09,10,10,10,13,13,13,12,12,12,09,09,09,09,09,09,11,11,11,11,11,11,09,00,09,08,08,08,10,10,10,10,10,10,08,08,08,06,06,06,07,07,07,07,07,07,05,05,05,04,04,04,06,06,06,07,07,07,06,06,06,06,06,08,08,08,08,09,09,09,08,08,08,08,08,08,09,09,09,09,09,09,07,07,07,06,06,06,08,08,08,08,08,08,07,07,07,07,07,07,09,09,09,10,10,10', '09,03,02,02,02,02,02,06,06,10,10,10', 'de_dust2_2x2', '0'),
(26, '193.192.58.206:27017', 44.718750, 16, '16', '23', 'cs16', 'PUB', 1, 'La_Cocaine Â® | DD2 Only', 'de_dust2', '16,17,17,19,21,24,26,28,30,31,31,31,31,31,31,29,28,25,23,20,19,18,17,17', '31', '32', 'RS', 1546257618, 1546257619, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'lacocaine', '15', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,02,05,06,07,08,08,09,09,09,11,12,13,13,12,14,15,17,19,21,23,25,26,28,29,29,29,27,25,23,21,19,16,14,12,10,08,08,08,10,12,14,16,18,21,23,25,27,29,28,29,28,26,24,20,20,17,15,13,12,11,12,12,14,15,17,19,22,24,27,29,30,30,30,31,30,30,26,26,23,22,19,18,16,16,17,16,17,17,19,21,24,26,28,30,31,31,31,31,31,31,29,28,25,23,20,19,18,17,17', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00023,00023,00021,00021,00020,00019,00019,00019,00018,00018,00018,00018,00018,00018,00018,00018,00016,00016,00016', '26,16,21,31,28,17', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,04,04,04,07,07,07,12,12,12,15,15,15,16,16,16,18,18,18,20,20,20,21,21,21,18,18,18,17,17,17,21,21,21,23,23,23,20,20,21,21,21,21,24,24,24,25,25,25', '27,31,14,11,07,02,02,08,20,26,31,31', 'de_dust2', '0'),
(25, '136.243.213.253:7778', 0.200000, 2, '24', '27', 'samp', 'DEFAULT', 1, '[K:RP] Kicevo RolePlay Community | Uskoro Open! |', 'San Andreas', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '0', '50', 'RS', 1546257622, 1546257623, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'Leafs', '10', 'Nema', '', '', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0000,0001,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00003,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002,00002', '0000,0000,0000,0000,0000,0000', '0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0000,0000,0000,0000,0000,0000,0001,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0001,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', '000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000,0000', 'San Andreas', '0'),
(28, '93.123.18.51:27016', 13.000000, 20, '20', '24', 'cs16', 'DM', 0, 'Lan-BG.INFO #DeathMatch[18+]', 'de_inferno', '03,04,04,04,06,06,07,00,10,11,10,11,09,08,00,08,07,07,06,04,02,02,00,02', '28', '32', 'BG', 1546257620, 1546257621, '|14|16|18|20|22|00|02|04|06|08|10|12', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'sG444', '16', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,01,01,01,02,02,03,02,05,00,08,11,00,00,15,00,15,00,15,00,11,11,09,00,05,04,02,02,01,03,04,04,04,06,06,07,09,00,00,10,11,00,00,08,00,00,07,06,04,02,02,00,02', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00024,00022,00022,00020,00021,00021,00021,00021,00020', '11,02,06,00,00,02', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,00,00,01,03,03,00,00,03,04,04,00,04,04,00,04,03,03,00', '02,02,02,02,02,03,00,00,00,02,04,00', 'de_dust2', '0'),
(27, '93.123.18.82:27016 ', 16.750000, 19, '19', '23', 'cs16', 'DD2', 0, 'Lan-BG.INFO #D2 Only [18+] ', 'de_dust2', '00,06,00,09,00,11,12,13,13,15,00,17,18,17,16,14,00,13,11,10,10,07,07,00', '11', '32', 'BG', 1546257619, 1546257620, '|13|15|17|19|21|23|01|03|05|07|09|11', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', 'sG444', '16', 'Nema', '', '', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,01,01,01,01,02,02,02,03,00,04,00,07,09,11,11,12,00,12,00,13,13,13,13,00,08,08,06,06,05,06,05,00,05,05,00,07,09,11,11,12,13,00,15,16,17,00,00,00,14,13,13,11,10,10,07,07,05', '|Tue|Wed|Thu|Fri|Sat|Sun|Mon', '|03|05|07|09|11|13|15|17|19|21|23|25|27|29|01', '00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00000,00023,00021,00021,00021,00020,00020,00019,00019,00019', '00,00,11,16,00,00', '00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,02,00,00,04,04,00,04,04,04,04,04,06,06,00,06,09,09,09,07,00,00', '05,07,00,03,03,04,00,00,05,17,00,00', 'de_dust2', '0');

-- --------------------------------------------------------

--
-- Table structure for table `shoutbox_s`
--

CREATE TABLE `shoutbox_s` (
  `id` int(11) NOT NULL,
  `sid` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `time` varchar(100) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoutbox_s`
--

INSERT INTO `shoutbox_s` (`id`, `sid`, `message`, `time`, `authorid`, `author`) VALUES
(1, '2', 'Test', '1541326737', '1', 'Bogoljub'),
(2, '4', 'Upadajte... ', '1541879063', '2', 'Spodoba');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `ime` varchar(100) NOT NULL,
  `prezime` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `register_time` varchar(100) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `sesija` varchar(100) NOT NULL,
  `activity` varchar(100) NOT NULL,
  `avatar` varchar(500) NOT NULL DEFAULT 'nopic.png',
  `hidemail` varchar(10) NOT NULL,
  `rank` varchar(1) NOT NULL DEFAULT '0',
  `ban` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `ime`, `prezime`, `password`, `email`, `register_time`, `ip`, `sesija`, `activity`, `avatar`, `hidemail`, `rank`, `ban`) VALUES
(1, 'Bogoljub', 'Bogoljub', 'Jevtic', '1099046a64f5e7879fa05ea259920516', 'csmodovi@gmail.com', '14.09.2018 12:09', '31.223.128.89', '0ff5014574908573f13492397c440fb2', '1544133676', 'nopic.png', '', '1', '0'),
(2, 'Spodoba', 'Husnija', 'Hajdarovic', 'f915586bf8627db9be5383fc0255946c', 'husnijahajdarovic98@gmail.com', '10.11.2018 07:11', '95.156.155.44', '4bb851f64f2a0f99c253bc84d8659d8b', '1542493739', 'avatar_1541879569.jpg', 'on', '0', '0'),
(3, 'Daki', 'Daki', 'Dakic', 'fc20f4663989dd236cc3f3bc5bb04cef', 'daki@dakic.com', '19.11.2018 05:11', '31.223.139.37', '954b00cc112373de5226f554cab8cab9', '1542647809', 'nopic.png', '', '0', '0'),
(4, 'TWcs', 'Teen', 'Wolf', '1acf5d9c3dcf1963bf67c448b9a1e3bf', 'skubishaaa@gmail.com', '22.11.2018 09:11', '5.133.145.126', 'efd284b6aaaf6e4030caca71a5da7e22', '1543950836', 'nopic.png', '', '0', '0'),
(5, 'AkiJ03', 'Aleksandar', 'JovanoviÄ‡', 'e1fa8410bb08440ecae46b380d970c81', 'akij03.official@gmail.com', '25.11.2018 11:11', '5.206.232.165', '15e7568c5aa218aa2cf427a53dcd7a4b', '1543187822', 'nopic.png', '', '0', '0'),
(6, 'assibraIncimb', 'assibraIncimb', 'assibraIncimb', 'a6c4152620af3b56b8d8d2823349c988', 'cgqvsInsipsUniom@1000xbetslots.xyz', '28.11.2018 02:11', '5.188.210.59', '5fb71d9895008f0112bccac3e8c946c2', '1543553861', 'nopic.png', '', '0', '0'),
(7, 'Janeevete', 'Janeevete', 'Janeevete', '964ee4ebc896cc5276b31ff0726c608e', 'tyiotwpp@gmail.com', '01.12.2018 06:12', '5.188.210.29', '73f1bb4c2eddcc5e1016e1a8201877c4', '1543688502', 'nopic.png', '', '0', '0'),
(8, 'SteleTele', 'Stefan', 'Carina', '17828343b821afe96aa56e66ae65f4dc', 'boykapro12@gmail.com', '04.12.2018 06:12', '87.116.190.140', '75d0dc5a290874a7abe5e344893a7608', '1545244104', 'nopic.png', '', '0', '0'),
(9, 'knele55', 'Knele', 'ProHunteR', '641deb2bbca449a13abbd360afd18eb6', 'knelepopovski@gmail.com', '08.12.2018 06:12', '92.53.39.182', '1f444b0e30c07000c8287af1485cbc59', '1544294490', 'nopic.png', '', '0', '0'),
(10, 'Leafs', 'Leafs', 'Community', '1ba7c3996b1fb5763533179f0df794c1', 'leafs.community@gmail.com', '09.12.2018 01:12', '87.116.179.65', '142f2bd18c04d8a4ea81ef0daa47aa64', '1545721279', 'nopic.png', '', '0', '0'),
(11, 'Vucko', 'Leafs', 'Community', '1ba7c3996b1fb5763533179f0df794c1', 'vutryks.gaming@gmail.com', '09.12.2018 01:12', '87.116.179.65', '', '', 'nopic.png', '', '0', '0'),
(12, 'Cobra', 'Mateo', 'Milanovic', '69cf935bfe00a75deed4db1e98a2e667', 'mateo.milanovic333@gmail.com', '13.12.2018 09:12', '78.0.173.136', '0a501a936c7f12e662da21cef96385bd', '1544735051', 'nopic.png', '', '0', '0'),
(13, 'Mladenov1c', 'Veljko', 'Mladenovic', '8a49f44aed8c1ca632ae52f9b9936abf', 'djokarakic86@gmail.com', '19.12.2018 12:12', '87.116.179.55', '9170c3a6b25388f9bcddce9757459ffc', '1545221733', 'nopic.png', '', '0', '0'),
(14, 'Djuk1c', 'Djukic', 'Vukasin', '1ad7f9dbbdf6d0b5b5ade4acf13477e3', 'dopefoxxx@gmail.com', '24.12.2018 06:12', '46.40.59.46', '06079783d56d7840362c741046dd0705', '1545768314', 'nopic.png', '', '0', '0'),
(15, 'lacocaine', 'Aleksandar', 'Cocaine', '00a0c87061d8a6d3d1aa11184d6e17fd', 'kristinaprasemoje@gmail.com', '26.12.2018 10:12', '92.42.249.126', '4fdf046864434a9142fedd5d801c400c', '1545862495', 'nopic.png', '', '0', '0'),
(16, 'sG444', 'sG444', 'sG444', '1e55dbf412cb74d5e2c21fb6452408c7', 'chabuka@all.bg', '28.12.2018 11:12', '109.199.144.109', '0af2b3a3e0dc6bbdd5d7fe44c949eb59', '1546195052', 'nopic.png', '', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `zahtevi`
--

CREATE TABLE `zahtevi` (
  `id` int(11) NOT NULL,
  `od` varchar(100) NOT NULL,
  `za` varchar(100) NOT NULL,
  `status` varchar(1) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zahtevi`
--

INSERT INTO `zahtevi` (`id`, `od`, `za`, `status`, `time`) VALUES
(1, '2', '1', '1', '1541879381');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acp_obavestenja`
--
ALTER TABLE `acp_obavestenja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_servers`
--
ALTER TABLE `b_servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `community`
--
ALTER TABLE `community`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `community_servers`
--
ALTER TABLE `community_servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maps`
--
ALTER TABLE `maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages_answers`
--
ALTER TABLE `messages_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `obavestenja`
--
ALTER TABLE `obavestenja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `poruke`
--
ALTER TABLE `poruke`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prijave_s`
--
ALTER TABLE `prijave_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_feed`
--
ALTER TABLE `profile_feed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_log`
--
ALTER TABLE `profile_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_visits`
--
ALTER TABLE `profile_visits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD KEY `id` (`id`);

--
-- Indexes for table `shoutbox_s`
--
ALTER TABLE `shoutbox_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `zahtevi`
--
ALTER TABLE `zahtevi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acp_obavestenja`
--
ALTER TABLE `acp_obavestenja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_logs`
--
ALTER TABLE `admin_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `b_servers`
--
ALTER TABLE `b_servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `community`
--
ALTER TABLE `community`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `community_servers`
--
ALTER TABLE `community_servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `maps`
--
ALTER TABLE `maps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=480;

--
-- AUTO_INCREMENT for table `messages_answers`
--
ALTER TABLE `messages_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `obavestenja`
--
ALTER TABLE `obavestenja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1363107;

--
-- AUTO_INCREMENT for table `poruke`
--
ALTER TABLE `poruke`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prijave_s`
--
ALTER TABLE `prijave_s`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_feed`
--
ALTER TABLE `profile_feed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_log`
--
ALTER TABLE `profile_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `profile_visits`
--
ALTER TABLE `profile_visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `shoutbox_s`
--
ALTER TABLE `shoutbox_s`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `zahtevi`
--
ALTER TABLE `zahtevi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
