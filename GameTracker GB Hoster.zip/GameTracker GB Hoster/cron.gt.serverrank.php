<?php 
include_once('/home/gbhoster/gt.gb-hoster.me/db_podaci.php');

error_reporting(E_ALL);

if (!$db=@mysql_connect(DB_HOST, DB_USER, DB_PASS))
{
	die ("<b>Doslo je do greske prilikom spajanja na MySQL...</b>");
}

if (!mysql_select_db(DB_NAME, $db))
{
	die ("<b>Greska prilikom biranja baze!</b>");
}

//						Counter Strike 1.6						\\

$g = "cs16";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Counter Strike Source					\\

$g = "css";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//					Counter Strike Global Ofensive				\\

$g = "csgo";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Call Of Duty 2						\\

$g = "cod2";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Call Of Duty 4						\\

$g = "cod4";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Minecraft						\\

$g = "minecraft";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						San Andreas MultiPlayer						\\

$g = "samp";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Team Fortres 2						\\

$g = "tf2";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}

//						Team Speak 3						\\

$g = "teamspeak3";

$server_rank = 1;

$server_query	= mysql_query("SELECT * FROM servers WHERE game = '$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}
/*
$i = 2;

if($i == "1"){
	$g = "cs16";
	} else if($i == "2"){
	$g = "css";
	} else if($i == "3"){
	$g = "csgo";
	} else if($i == "4"){
	$g = "cod2";
	} else if($i == "5"){
	$g = "cod4";
	} else if($i == "6"){
	$g = "minecraft";
	} else if($i == "7"){
	$g = "samp";
	} else if($i == "8"){
	$g = "tf2";
	} else if($i == "9"){
	$g = "teamspeak3";
} else {}

$server_rank = 1;
// rank_pts+0 = order fix
$server_query	= mysql_query("SELECT * FROM servers WHERE game='$g' ORDER BY rank_pts DESC");
while($server_row = mysql_fetch_assoc($server_query)){
	$server_id		= $server_row['id'];
	$rank           = $server_row['rank'];
	$best_rank      = $server_row['best_rank'];
	$worst_rank     = $server_row['worst_rank'];
	
if($rank == "99999"){} else {
		
		$update_query	= mysql_query("UPDATE servers SET rank='$server_rank' WHERE id='$server_id'");
		$server_rank++;
		
		$testrank++;
		
		echo 'SRV ID: '.$server_id.' SRV Rank: '.$testrank.'<br/>';
		
		if($best_rank == "" OR $best_rank =="0"){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank < $best_rank){
			mysql_query("UPDATE servers SET best_rank='$testrank' WHERE id='$server_id'");
		}
		
		if($worst_rank == "" OR $worst_rank =="0"){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
			} else if($testrank > $worst_rank){
			mysql_query("UPDATE servers SET worst_rank='$testrank' WHERE id='$server_id'");
		}	
		
	}
	
}
*/
?>