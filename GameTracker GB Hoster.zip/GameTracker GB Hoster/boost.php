    <?php
	defined("access") or die("Nedozvoljen pristup");
	?>

	
		  <div class="section-title">
		  
		  <h1> <?php echo $lang['boost_server']; ?> </h1>
		  </div>

<br />

<!-- bih -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/BA.png"> </center>
</td>

<td valign="top">
Bosnia and Herzegovina <br />
<?php echo $lang['boost_info1']; ?>: 091810700 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 091810700 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 2,34 BAM + PDV
</td>

</tr>
</table>

<!-- rs -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/RS.png"> </center>
</td>

<td valign="top">
Serbia <br />
<?php echo $lang['boost_info1']; ?>: 1310 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 1310 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 120 RSD
</td>

</tr>
</table>

<!-- hr -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/HR.png"> </center>
</td>

<td valign="top">
Croatia <br />
<?php echo $lang['boost_info1']; ?>: 866866 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 866866 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 6,20 KN
</td>

</tr>
</table>

<!-- al -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/AL.png"> </center>
</td>

<td valign="top">
Albania <br />
<?php echo $lang['boost_info1']; ?>: 54345 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 54345 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 120.00 ALL
</td>

</tr>
</table>

<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/AT.png"> </center>
</td>

<td valign="top">
Austria <br />
<?php echo $lang['boost_info1']; ?>: 0900506506 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 0900506506 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: Preis: €1.10
</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/BG.png"> </center>
</td>

<td valign="top">
Bulgaria <br />
<?php echo $lang['boost_info1']; ?>: 1916 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 1916 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 2,40 BGN

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/FR.png"> </center>
</td>

<td valign="top">
France <br />
<?php echo $lang['boost_info1']; ?>: 83355 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 83355 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: Prix: €1,00

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/DE.png"> </center>
</td>

<td valign="top">
Germany <br />
<?php echo $lang['boost_info1']; ?>: 89000 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 89000 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: Preis: €0.99

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/XK.png"> </center>
</td>

<td valign="top">
Kosovo (Pokrajina) <br />
<?php echo $lang['boost_info1']; ?>: 55050 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 55050 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: €1.00

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/MK.png"> </center>
</td>

<td valign="top">
Macedonia <br />
<?php echo $lang['boost_info1']; ?>: 141551 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 141551 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 59.00 MKD

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/ME.png"> </center>
</td>

<td valign="top">
Montenegro <br />
<?php echo $lang['boost_info1']; ?>: 14741 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 14741 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: €1.02

</td>

</tr>
</table>


<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/RO.png"> </center>
</td>

<td valign="top">
Romania <br />
<?php echo $lang['boost_info1']; ?>: 1235 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 1235 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: €1.00 + TVA

</td>

</tr>
</table>

<!-- -->
<table class="mh">
<tr>
  <th width="50"></th>
  <th width="900"></th>
</tr>


<tr>

<td valign="top">
<center> <img src="/ime/flags/RU.png"> </center>
</td>

<td valign="top">
Russia <br />
<?php echo $lang['boost_info1']; ?>: 4448 <br />
<?php echo $lang['boost_info2']; ?>: TXT GTBA IP adresa Nick posaljete na broj 4448 <br />
<?php echo $lang['boost_info3']; ?>: TXT GTBA 193.104.68.58:27025 nick <br />
<?php echo $lang['boost_info4']; ?>: 70.00 RUB

</td>

</tr>
</table>