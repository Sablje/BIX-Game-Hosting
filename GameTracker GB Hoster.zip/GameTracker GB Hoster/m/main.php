    <?php
	defined("access") or die("Nedozvoljen pristup");
	?>
			
			<div class="row">
            <a href="servers/cs16">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-cs16.png">
					<p>Counter-Strike 1.6</p>
				</div>
			</div>
			</a>

            <a href="servers/css">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-css.png">
					<p>Counter-Strike Source</p>
				</div>
			</div>
			</a>

            <a href="servers/csgo">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-csgo.png">
					<p>Counter-Strike Global Offensive</p>
				</div>
			</div>
			</a>
						
            <a href="servers/cod2">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-cod2.png">
					<p>Call of Duty 2</p>
				</div>
			</div>
			</a>

			<a href="servers/cod4">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-cod4.png">
					<p>Call of Duty 4</p>
				</div>
			</div>
			</a>
			
			<a href="servers/minecraft">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-minecraft.png">
					<p>Minecraft</p>
				</div>
			</div>
			</a>
			
			<a href="servers/samp">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-samp.png">
					<p>San Andreas MultiPlayer</p>
				</div>
			</div>
			</a>

			<a href="servers/tf2">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-tf2.png">
					<p>TeamFortress 2</p>
				</div>
			</div>
			</a>

			<a href="servers/teamspeak3">
			<div class="span4">
				<div class="glyph">
					<img width="16" height="16" src="/ime/games/game-teamspeak3.png">
					<p>TeamSpeak 3</p>
				</div>
			</div>
			</a>
			
		</div> <!-- /row -->